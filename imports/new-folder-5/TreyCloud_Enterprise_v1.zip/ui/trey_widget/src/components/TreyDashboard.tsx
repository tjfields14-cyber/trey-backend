
import React from 'react'
import '../theme/theme.css'

export default function TreyDashboard() {
  return (
    <div className="breathing-glow" style={{
      padding: '20px',
      border: '2px solid var(--amethyst)',
      borderRadius: '12px'
    }}>
      <h1 style={{color:'var(--amethyst)'}}>Trey Cloud Dashboard</h1>
      <p>Gothic Noir • Afrofuturist • Amethyst Glow</p>
    </div>
  )
}
