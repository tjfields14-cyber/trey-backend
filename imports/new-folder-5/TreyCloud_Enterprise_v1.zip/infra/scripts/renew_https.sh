
#!/usr/bin/env bash
echo "If using certbot on a real domain, this script can be wired to cron to renew certificates."
