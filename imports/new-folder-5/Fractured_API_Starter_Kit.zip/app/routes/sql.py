# SQL (read-only) route placeholder
