from fastapi import APIRouter
router = APIRouter(prefix="/characters", tags=["characters"])

# Placeholder for expansion
@router.get("/")
def list_characters():
    return {"characters": []}
