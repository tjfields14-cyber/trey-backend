
-- Supabase schema placeholder
create table if not exists kb_chunks(
 id uuid primary key,
 content text,
 source text,
 created_at timestamp default now()
);
