
import React from 'react'
import TreyDashboard from './components/TreyDashboard'

export default function App(){
  return (
    <div style={{margin:'40px'}}>
      <TreyDashboard/>
    </div>
  )
}
