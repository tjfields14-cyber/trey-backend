
from .embedding_engine import EmbeddingEngine
from .chroma_local import ChromaLocal
from .weaviate_cloud import WeaviateCloud
import uuid

class HybridSemanticIndexer:
    def __init__(self, use_local=True, use_cloud=False, weaviate_url=None, weaviate_key=None):
        self.embedder = EmbeddingEngine()
        self.local = ChromaLocal() if use_local else None
        self.cloud = WeaviateCloud(weaviate_url, weaviate_key) if use_cloud else None

    def ingest(self, text, source):
        emb = self.embedder.embed_text(text)
        doc_id = str(uuid.uuid4())

        if self.local:
            self.local.add([doc_id],[emb],[{"source":source}],[text])

        if self.cloud:
            self.cloud.add("KBEntry", [{"content":text,"source":source,"vector":emb}])

        return {"id":doc_id,"source":source}

    def search(self, query, n=5):
        q_emb = self.embedder.embed_text(query)

        results = {}
        if self.local:
            results["local"] = self.local.query(q_emb,n)
        if self.cloud:
            results["cloud"] = self.cloud.query("KBEntry",q_emb,n)

        return results
