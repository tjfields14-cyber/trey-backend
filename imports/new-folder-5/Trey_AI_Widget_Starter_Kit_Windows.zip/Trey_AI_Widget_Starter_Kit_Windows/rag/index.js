import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import chokidar from "chokidar";
import dotenv from "dotenv";

dotenv.config();
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const EMBED_MODEL = "mxbai-embed-large"; // change if desired

const ragDir = path.join(process.cwd(), "rag");
const docsDir = path.join(ragDir, "docs");
const outPath = path.join(ragDir, "index.json");

if (!fs.existsSync(docsDir)) fs.mkdirSync(docsDir, { recursive: true });

async function embed(text){
  const r = await fetch(`${OLLAMA_BASE}/api/embeddings`, {
    method:"POST",
    headers:{ "Content-Type":"application/json" },
    body: JSON.stringify({ model: EMBED_MODEL, prompt: text })
  });
  const j = await r.json();
  return j.embedding;
}

async function indexAll(){
  console.log("Indexing docs...");
  const entries = fs.readdirSync(docsDir).filter(f => f.endsWith(".txt"));
  const chunks = [];
  for (const f of entries){
    const full = path.join(docsDir, f);
    const text = fs.readFileSync(full, "utf-8");
    // simple chunking by paragraphs
    const parts = text.split(/\n\s*\n/g).map(s=>s.trim()).filter(Boolean);
    for (const p of parts){
      const vec = await embed(p);
      chunks.push({ text: p, vec });
    }
  }
  const out = { meta:{ embedModel: EMBED_MODEL, createdAt: new Date().toISOString() }, chunks };
  fs.writeFileSync(outPath, JSON.stringify(out));
  console.log(`Indexed ${chunks.length} chunks -> ${outPath}`);
}

if (process.argv.includes("--watch")){
  console.log("Watching ./rag/docs for changes...");
  chokidar.watch(docsDir).on("all", debounce(async ()=>{
    try { await indexAll(); } catch (e){ console.error("Index error:", e); }
  }, 500));
} else {
  indexAll().catch(e=>console.error(e));
}

function debounce(fn, ms){
  let t; return (...a)=>{ clearTimeout(t); t = setTimeout(()=>fn(...a), ms); };
}
