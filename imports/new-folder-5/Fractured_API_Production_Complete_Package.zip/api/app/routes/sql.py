from fastapi import APIRouter
from app.db.connection import get_conn, release_conn

router = APIRouter(prefix="/sql", tags=["sql"])

@router.post("/query")
def read_only_query(query: str):
    forbidden = ["insert", "update", "delete", "drop", "alter"]
    if any(bad in query.lower() for bad in forbidden):
        return {"error": "Write operations are not allowed."}

    conn = get_conn()
    cur = conn.cursor()
    cur.execute(query)
    rows = cur.fetchall()
    cols = [desc[0] for desc in cur.description]
    release_conn(conn)

    return {"columns": cols, "rows": rows}
