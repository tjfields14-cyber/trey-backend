#!/usr/bin/env bash
#
# deploy_fractured_structure.sh
#
# Deploys the EMPTY Fractured folder structure bundle to the correct locations
# on an Ubuntu system, using the dedicated service user `fracturedsvc`.
#
# Usage:
#   1) Copy Fractured_Empty_Folder_Structure.zip to your server
#   2) unzip Fractured_Empty_Folder_Structure.zip -d ~/fractured_empty
#   3) cd ~/fractured_empty
#   4) sudo bash deploy_fractured_structure.sh
#
set -e

SERVICE_USER="fracturedsvc"
SERVICE_HOME="/home/${SERVICE_USER}"
PROJECT_ROOT="${SERVICE_HOME}/fractured_api"
SOURCE_ROOT="$(pwd)"

echo "==> Fractured Structure Deployment"
echo "    Service user  : ${SERVICE_USER}"
echo "    Service home  : ${SERVICE_HOME}"
echo "    Project root  : ${PROJECT_ROOT}"
echo "    Source root   : ${SOURCE_ROOT}"
echo

# Must be run as root (or via sudo)
if [[ "$EUID" -ne 0 ]]; then
  echo "ERROR: This script must be run as root (use: sudo bash deploy_fractured_structure.sh)"
  exit 1
fi

# 1) Create service user if missing
if id "${SERVICE_USER}" >/dev/null 2>&1; then
  echo "==> User ${SERVICE_USER} already exists."
else
  echo "==> Creating system user ${SERVICE_USER}..."
  adduser --system --home "${SERVICE_HOME}" --shell /bin/bash "${SERVICE_USER}"
  mkdir -p "${SERVICE_HOME}"
  chown "${SERVICE_USER}:${SERVICE_USER}" "${SERVICE_HOME}"
fi

# 2) Deploy fractured_api folder structure
if [[ ! -d "${SOURCE_ROOT}/fractured_api" ]]; then
  echo "ERROR: Expected 'fractured_api' folder in ${SOURCE_ROOT}, but it was not found."
  echo "Make sure you unzipped Fractured_Empty_Folder_Structure.zip and are in that directory."
  exit 1
fi

echo "==> Deploying fractured_api structure to ${PROJECT_ROOT} ..."
mkdir -p "${PROJECT_ROOT}"
# Use rsync-like behavior via cp to copy directory tree and files
cp -R "${SOURCE_ROOT}/fractured_api/." "${PROJECT_ROOT}/"

echo "==> Setting ownership to ${SERVICE_USER}:${SERVICE_USER} ..."
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${PROJECT_ROOT}"

# 3) Deploy system-wide config stubs (systemd + cloudflared)
# systemd service unit stubs
if [[ -d "${SOURCE_ROOT}/etc/systemd" ]]; then
  echo "==> Copying systemd service stubs to /etc/systemd/system/ ..."
  mkdir -p /etc/systemd/system
  cp -n "${SOURCE_ROOT}/etc/systemd/"*.service /etc/systemd/system/ 2>/dev/null || true
  echo "    (These are placeholders: edit them later with the final ExecStart and paths.)"
else
  echo "==> No etc/systemd folder found in ${SOURCE_ROOT}, skipping systemd stub deployment."
fi

# cloudflared config stubs
if [[ -d "${SOURCE_ROOT}/etc/cloudflared" ]]; then
  echo "==> Copying cloudflared config stubs to /etc/cloudflared/ ..."
  mkdir -p /etc/cloudflared
  cp -n "${SOURCE_ROOT}/etc/cloudflared/"* /etc/cloudflared/ 2>/dev/null || true
  echo "    (Edit /etc/cloudflared/fractured-api.yml with your credentials & hostname.)"
else
  echo "==> No etc/cloudflared folder found in ${SOURCE_ROOT}, skipping Cloudflare stub deployment."
fi

echo
echo "=============================================================="
echo " Fractured empty folder structure deployed successfully."
echo " Next steps:"
echo "   1) Populate ${PROJECT_ROOT} with actual app code, scripts, and configs"
echo "      (e.g., from your production bundle or installer script)."
echo "   2) Edit any service files in /etc/systemd/system/ as needed."
echo "   3) Edit /etc/cloudflared/fractured-api.yml with the real tunnel info."
echo "   4) Proceed with installing dependencies and running your full installer."
echo "=============================================================="
