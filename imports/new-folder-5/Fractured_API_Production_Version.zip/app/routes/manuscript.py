from fastapi import APIRouter
from app.db.connection import get_conn, release_conn

router = APIRouter(prefix="/manuscript", tags=["manuscript"])

@router.get("/chapter/{chapter_number}")
def get_chapter(chapter_number: int):
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("SELECT id, title, word_count FROM chapters WHERE chapter_number=%s", (chapter_number,))
    row = cur.fetchone()
    if not row:
        release_conn(conn)
        return {"error": "Chapter not found"}

    chapter_id, title, wc = row

    cur.execute("SELECT paragraph_number, text FROM paragraphs WHERE chapter_id=%s ORDER BY paragraph_number",
                (chapter_id,))
    paragraphs = [{"paragraph_number": r[0], "text": r[1]} for r in cur.fetchall()]

    release_conn(conn)
    return {
        "chapter_number": chapter_number,
        "title": title,
        "word_count": wc,
        "paragraphs": paragraphs
    }
