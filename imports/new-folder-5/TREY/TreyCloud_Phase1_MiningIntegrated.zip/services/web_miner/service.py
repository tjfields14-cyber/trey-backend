
import requests
from bs4 import BeautifulSoup

class WebMiner:
    def fetch_html(self, url: str) -> str:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        return resp.text

    def extract_text(self, html: str) -> str:
        soup = BeautifulSoup(html, "html.parser")
        return soup.get_text(" ", strip=True)

    def crawl(self, url: str) -> dict:
        html = self.fetch_html(url)
        text = self.extract_text(html)
        return {"url": url, "text": text}
