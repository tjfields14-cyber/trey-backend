# FRACTURED • World Lore Static Site

This is a non-interactive, static HTML/CSS prototype of the **Fractured World Lore Archive**.

All files are inside the `site/` folder.

---
## 1. Run Locally (Python)

```bash
cd site
python3 -m http.server 8080
# then open http://localhost:8080/index.html
```

On Windows you can use:

```bash
cd site
python -m http.server 8080
```

---
## 2. Run Locally (Node.js via `serve`)

```bash
npm install -g serve
cd site
serve -l 8080
# then open http://localhost:8080
```

---
## 3. GitHub Pages Deployment

1. Create a new GitHub repo (e.g. `fractured-lore-site`).
2. Copy the contents of `site/` to the root of the repo.
3. Commit and push.
4. In GitHub → Settings → Pages:
   - Source: `Deploy from a branch`
   - Branch: `main` (or `master`) → `/ (root)`.
5. Save; GitHub will give you a Pages URL like:
   `https://your-username.github.io/fractured-lore-site/`

Optional: keep `.nojekyll` at the root to prevent Jekyll processing.

---
## 4. Netlify Deployment

1. Drag-and-drop the `site/` folder into the Netlify dashboard _or_
2. Connect your repo and set:
   - **Build command:** (leave empty, this is a pure static site)
   - **Publish directory:** `site` (or `.` if the files live at repo root)

Example `netlify.toml` if the site files are at repo root:

```toml
[build]
  command = ""
  publish = "."

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---
## 5. Vercel Deployment

1. Create a new Vercel project from your repo.
2. Set the **Output Directory** to `site` (or `.` if your files are at root).
3. No build command is required.

Example `vercel.json` for a basic static deployment from repo root:

```json
{
  "version": 2,
  "public": true
}
```

---
## 6. Run Scripts

At the root of this kit:

- `run.sh` — Bash helper for local preview.
- `start.bat` — Windows helper for local preview.

Both assume you have Python installed.
