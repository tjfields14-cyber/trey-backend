import express from "express";
import fetch from "node-fetch";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { customAlphabet } from "nanoid";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MODEL = process.env.MODEL || "llama3:8b";
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const PROXY_PORT = Number(process.env.PROXY_PORT || 3000);
const WEB_PORT = Number(process.env.WEB_PORT || 5173);
const ADMIN_SECRET = process.env.WIDGET_SECRET || "";
const RATE_WINDOW_MS = Number(process.env.RATE_WINDOW_MS || 60000);
const RATE_MAX = Number(process.env.RATE_MAX || 60);

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(morgan("dev"));

const limiter = rateLimit({ windowMs: RATE_WINDOW_MS, max: RATE_MAX });
app.use(limiter);

// ---- Data ----
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const keysPath = path.join(dataDir, "keys.json");
if (!fs.existsSync(keysPath)) fs.writeFileSync(keysPath, JSON.stringify({keys:[]}, null, 2));
let keys = JSON.parse(fs.readFileSync(keysPath, "utf-8")).keys; // [{key,name,note,limit,role,quota_per_day,usage_day,used_today,webhook_url,threshold_percent,created_at,active}]
const settingsPath = path.join(dataDir, "settings.json");
if (!fs.existsSync(settingsPath)) fs.writeFileSync(settingsPath, JSON.stringify({ webhook_url:"", alert_threshold_percent:80, slack_webhook_url:"" }, null, 2));
let settings = JSON.parse(fs.readFileSync(settingsPath, "utf-8"));

function saveKeys(){ fs.writeFileSync(keysPath, JSON.stringify({keys}, null, 2)); }
function saveSettings(){ fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2)); }

// ---- Admin ----
function adminOnly(req,res,next){
  const tok = req.headers["x-admin-secret"];
  if (ADMIN_SECRET && tok === ADMIN_SECRET) return next();
  return res.status(401).json({ error: "Admin Unauthorized" });
}

const makeKey = () => customAlphabet("23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", 40)();
function findKey(k){ return keys.find(x => x.key === k && x.active !== false); }

app.get("/api/keys", adminOnly, (req,res)=> res.json({ keys }));
app.post("/api/keys", adminOnly, (req,res)=>{
  const { name = "unnamed", note = "", limit = 60, role = "viewer", quota_per_day = null, webhook_url = "", threshold_percent = null } = req.body || {};
  const key = makeKey();
  const item = { key, name, note, limit: Number(limit)||60, role, quota_per_day: quota_per_day? Number(quota_per_day) : null, usage_day: null, used_today: 0, webhook_url: webhook_url || "", threshold_percent: threshold_percent? Number(threshold_percent) : null, created_at: new Date().toISOString(), active: true };
  keys.push(item); saveKeys();
  res.json({ ...item, remaining: item.quota_per_day ?? null });
});
app.delete("/api/keys/:key", adminOnly, (req,res)=>{
  const { key } = req.params;
  const idx = keys.findIndex(k => k.key === key);
  if (idx === -1) return res.status(404).json({ error: "not found" });
  keys[idx].active = false; saveKeys();
  res.json({ ok: true });
});

app.get("/api/settings", adminOnly, (req,res)=> res.json(settings));
app.post("/api/settings", adminOnly, (req,res)=>{
  const { webhook_url, alert_threshold_percent, slack_webhook_url } = req.body || {};
  if (typeof webhook_url === "string") settings.webhook_url = webhook_url;
  const p = Number(alert_threshold_percent);
  if (!Number.isNaN(p) && p >= 1 && p <= 100) settings.alert_threshold_percent = p;
  if (typeof slack_webhook_url === "string") settings.slack_webhook_url = slack_webhook_url;
  saveSettings();
  res.json(settings);
});

// ---- Auth + rate + quota + roles ----
const perKeyUsage = new Map();
const perKeyTotals = new Map();
const perKeyMinute = new Map();
const alertedThreshold = new Set();
function utcDay(){ return new Date().toISOString().slice(0,10); }

function roleAllows(role, req){
  const method = req.method.toUpperCase();
  const path = req.path;
  if (role === "viewer") {
    if (path === "/api/trey" && method === "POST") return true;
    if (path === "/api/health" && method === "GET") return true;
    return false;
  }
  if (role === "power") {
    if (path === "/api/trey" && method === "POST") return true;
    if (path.startsWith("/api/metrics") && method === "GET") return true;
    if (path === "/api/health" && method === "GET") return true;
    if (path === "/api/logs/current" && method === "GET") return true;
    return false;
  }
  if (role === "admin-proxy") return true;
  return false;
}

function thresholdFor(rec){
  return rec.threshold_percent != null ? Number(rec.threshold_percent) : (settings.alert_threshold_percent || 80);
}
function webhookTargets(rec){
  const targets = [];
  if (settings.webhook_url) targets.push({ type:"generic", url: settings.webhook_url });
  if (settings.slack_webhook_url) targets.push({ type:"slack", url: settings.slack_webhook_url });
  if (rec.webhook_url) targets.push({ type:"generic", url: rec.webhook_url });
  return targets;
}
async function sendSlack(url, title, text, color){
  const payload = {
    attachments: [{
      color: color || "#fcd34d",
      title,
      text,
      mrkdwn_in: ["text"]
    }]
  };
  try { await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) }); } catch(e){ console.warn("Slack webhook failed:", e.message); }
}
async function sendGeneric(url, obj){
  try { await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(obj) }); } catch(e){ console.warn("Generic webhook failed:", e.message); }
}

async function maybeAlert(kind, rec){
  const targets = webhookTargets(rec);
  if (!targets.length) return;
  const percent = rec.quota_per_day ? Math.round((rec.used_today / rec.quota_per_day) * 100) : null;
  const obj = { kind, key: rec.key, name: rec.name, role: rec.role, quota_per_day: rec.quota_per_day, used_today: rec.used_today, usage_day: rec.usage_day, percent, ts: new Date().toISOString() };
  for (const t of targets){
    if (t.type === "slack"){
      const title = kind === "threshold" ? "⚠️ Quota threshold reached" : "⛔ Quota exhausted";
      const lines = [
        `*Key:* ${rec.name || rec.key.slice(0,6)}`,
        `*Role:* ${rec.role}`,
        `*Used Today:* ${rec.used_today}${rec.quota_per_day?` / ${rec.quota_per_day}`:""}`,
        rec.quota_per_day? `*Percent:* ${percent}%` : null,
        `*Date (UTC):* ${rec.usage_day}`
      ].filter(Boolean).join("\n");
      await sendSlack(t.url, title, lines, kind==="threshold"?"#f59e0b":"#ef4444");
    } else {
      await sendGeneric(t.url, obj);
    }
  }
}

function authClient(req){
  const apiKey = req.headers["x-api-key"];
  if (apiKey){
    const rec = findKey(apiKey);
    if (!rec) return { ok:false, status:401, error:"Invalid API key" };

    // role gate
    if (!roleAllows(rec.role || "viewer", req)) return { ok:false, status:403, error:"Forbidden for this key role" };

    // daily reset
    const day = utcDay();
    if (rec.usage_day !== day) { rec.usage_day = day; rec.used_today = 0; alertedThreshold.delete(rec.key); saveKeys(); }

    // quota
    if (rec.quota_per_day != null && rec.used_today >= rec.quota_per_day) { maybeAlert("exhausted", rec); return { ok:false, status:429, error:"Quota Exceeded" }; }

    // limiter
    const now = Date.now();
    let u = perKeyUsage.get(apiKey);
    if (!u || now - u.windowStart >= RATE_WINDOW_MS) { u = { windowStart: now, count: 0 }; }
    if (u.count >= (rec.limit || 60)) { perKeyUsage.set(apiKey, u); return { ok:false, status:429, error:"Key rate limit exceeded" }; }
    u.count += 1; perKeyUsage.set(apiKey, u);

    // usage inc + threshold alert maybe
    rec.used_today += 1; saveKeys();
    const thr = thresholdFor(rec);
    if (rec.quota_per_day && (rec.used_today / rec.quota_per_day) * 100 >= thr && !alertedThreshold.has(rec.key)){
      alertedThreshold.add(rec.key);
      maybeAlert("threshold", rec);
    }
    if (rec.quota_per_day && rec.used_today >= rec.quota_per_day) {
      maybeAlert("exhausted", rec);
    }

    // analytics
    perKeyTotals.set(apiKey, (perKeyTotals.get(apiKey)||0) + 1);
    const m = Math.floor(now/60000);
    const arr = perKeyMinute.get(apiKey) || [];
    if (!arr.length || arr[arr.length-1].t !== m) arr.push({ t:m, count:1 });
    else arr[arr.length-1].count += 1;
    while (arr.length > 1440) arr.shift();
    perKeyMinute.set(apiKey, arr);

    return { ok:true, who: { type:"key", key: apiKey, name: rec.name, role: rec.role } };
  }

  // fallback secret
  const token = req.headers["x-widget-secret"];
  if (!ADMIN_SECRET) return { ok:true, who: { type:"secretless" } };
  if (token === ADMIN_SECRET) return { ok:true, who: { type:"admin-secret" } };
  return { ok:false, status:401, error:"Unauthorized" };
}

// ---- Logs rotation & metrics (same as previous bundle) ----
const logsDir = path.join(__dirname, "logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
const nano8 = customAlphabet("0123456789abcdef", 8);
let currentDay = new Date().toISOString().slice(0,10);
let sessionId = nano8();
let sessionFile = path.join(logsDir, `SESSION-${currentDay}-${sessionId}.log`);
function rotateIfNeeded(){ const day = new Date().toISOString().slice(0,10); if (day !== currentDay) { currentDay = day; sessionId = nano8(); sessionFile = path.join(logsDir, `SESSION-${currentDay}-${sessionId}.log`); } }
function writeLog(obj){ rotateIfNeeded(); fs.appendFileSync(sessionFile, JSON.stringify(obj)+"\n"); }

const startedAt = Date.now();
let requestsTotal = 0;
let streamCharsTotal = 0;
let minuteBuckets = [];
function bumpMinute(){ const m = Math.floor(Date.now()/60000); const last = minuteBuckets[minuteBuckets.length-1]; if (!last || last.t !== m){ minuteBuckets.push({ t:m, count:1 }); if (minuteBuckets.length > 1440) minuteBuckets.shift(); } else last.count += 1; }
function metrics(){ const nowMin = Math.floor(Date.now()/60000); const lastMin = minuteBuckets.find(b=>b.t===nowMin) || { count:0 }; const mins = Math.max(1, Math.floor((Date.now()-startedAt)/60000)); const sum = minuteBuckets.reduce((a,b)=>a+b.count,0); return { uptime_sec: Math.floor((Date.now()-startedAt)/1000), started_at: new Date(startedAt).toISOString(), requests_total: requestsTotal, stream_chars_total: streamCharsTotal, reqs_last_min: lastMin.count, avg_reqs_per_min: Number((sum/mins).toFixed(2)), session_log_file: path.basename(sessionFile), minute_buckets: minuteBuckets }; }

app.get("/api/health", (req,res)=>{ rotateIfNeeded(); res.json({ ok:true, model: MODEL, ollama: OLLAMA_BASE, sessionLog: path.basename(sessionFile) }); });
app.get("/api/metrics", (req,res)=> res.json(metrics()));
app.get("/api/metrics/keys", adminOnly, (req,res)=>{
  const nowMin = Math.floor(Date.now()/60000);
  const out = keys.filter(k=>k.active!==false).map(k=>{
    const series = (perKeyMinute.get(k.key)||[]).filter(b=> b.t >= nowMin-59);
    const last = series.find(b=>b.t===nowMin)?.count || 0;
    const remaining = k.quota_per_day==null ? null : Math.max(0, k.quota_per_day - (k.used_today||0));
    return { key:k.key, name:k.name, note:k.note, limit:k.limit, role:k.role, quota_per_day:k.quota_per_day, used_today:k.used_today||0, remaining, last_min: last, threshold_percent: k.threshold_percent, webhook_url: k.webhook_url, series };
  });
  res.json({ keys: out });
});
app.get("/api/metrics/csv", (req,res)=>{
  const m = metrics();
  res.setHeader("Content-Type","text/csv");
  res.setHeader("Content-Disposition","attachment; filename=metrics.csv");
  let csv = "epoch_minute,iso_minute,count\n";
  for (const b of m.minute_buckets){ csv += `${b.t},${new Date(b.t*60000).toISOString()},${b.count}\n`; }
  csv += `\nstarted_at,${m.started_at}\n`;
  csv += `uptime_sec,${m.uptime_sec}\n`;
  csv += `requests_total,${m.requests_total}\n`;
  csv += `stream_chars_total,${m.stream_chars_total}\n`;
  csv += `avg_reqs_per_min,${m.avg_reqs_per_min}\n`;
  res.end(csv);
});
app.get("/api/logs/current", (req,res)=>{ rotateIfNeeded(); const fname = path.basename(sessionFile); res.setHeader("Content-Type","text/plain; charset=utf-8"); res.setHeader("Content-Disposition", `attachment; filename=${fname}`); fs.createReadStream(sessionFile).pipe(res); });

// --- SQLite RAG + Chat ---
const ragDir = path.join(__dirname, "rag");
const dbPath = path.join(ragDir, "vectors.db");
let db = null;
try { db = new Database(dbPath); db.exec(`CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, text TEXT NOT NULL, vec BLOB NOT NULL);`); } catch (e) { console.warn("SQLite warn:", e.message); }
function cosine(q,v){ let dot=0,nq=0,nv=0; const len=Math.min(q.length,v.length); for(let i=0;i<len;i++){ dot+=q[i]*v[i]; nq+=q[i]*q[i]; nv+=v[i]*v[i]; } return dot/(Math.sqrt(nq)*Math.sqrt(nv)+1e-8); }
async function embed(text){ const r = await fetch(`${OLLAMA_BASE}/api/embeddings`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model: "mxbai-embed-large", prompt: text }) }); const j = await r.json(); return Float32Array.from(j.embedding); }
function allChunks(){ if (!db) return []; const rows = db.prepare("SELECT id,text,vec FROM chunks").all(); return rows.map(r=>({ id:r.id, text:r.text, vec:new Float32Array(new Uint8Array(r.vec).buffer) })); }
let memory = allChunks();

app.post("/api/trey", async (req,res)=>{
  const auth = authClient(req);
  if (!auth.ok) return res.status(auth.status).json({ error: auth.error });
  const now = new Date().toISOString();
  const { messages = [], stream = true } = req.body || {};
  const mNow = Math.floor(Date.now()/60000); const last = minuteBuckets[minuteBuckets.length-1];
  if (!last || last.t !== mNow){ minuteBuckets.push({ t:mNow, count:1 }); if (minuteBuckets.length > 1440) minuteBuckets.shift(); } else last.count += 1;
  requestsTotal += 1;

  let system = `You are Trey, the Chapterhouse assistant. Be concise and helpful.`;
  try{
    const lastUser = [...messages].reverse().find(m=>m.role==="user")?.content || "";
    if (memory.length && lastUser){
      const qv = await embed(lastUser);
      const top = memory.map(ch=>({ score: cosine(qv,ch.vec), text: ch.text })).sort((a,b)=>b.score-a.score).slice(0,4);
      const ctx = top.map(s=>s.text).join("\n---\n");
      system += `\nUse ONLY the following context if relevant:\n${ctx}`;
    }
  }catch(e){ console.warn("RAG:", e.message); }

  const payload = { model: MODEL, messages: [{ role:"system", content: system }, ...messages], stream: Boolean(stream) };
  writeLog({ t: now, event:"request", payload, who: auth.who });

  const upstream = await fetch(`${OLLAMA_BASE}/api/chat`, { method:"POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify(payload) });

  res.setHeader("Content-Type","application/json");
  if (!payload.stream){
    const j = await upstream.json();
    writeLog({ t: new Date().toISOString(), event:"response", data: j });
    try{ streamCharsTotal += JSON.stringify(j).length }catch{}
    return res.json(j);
  } else {
    let acc = "";
    for await (const chunk of upstream.body){
      const part = chunk.toString("utf-8");
      acc += part; streamCharsTotal += part.length;
      res.write(part);
    }
    writeLog({ t: new Date().toISOString(), event:"response_stream_raw", data: acc });
    return res.end();
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.listen(PROXY_PORT, ()=>{
  console.log(`API proxy on http://localhost:${PROXY_PORT}`);
  console.log(`UI on http://localhost:${WEB_PORT}`);
});
