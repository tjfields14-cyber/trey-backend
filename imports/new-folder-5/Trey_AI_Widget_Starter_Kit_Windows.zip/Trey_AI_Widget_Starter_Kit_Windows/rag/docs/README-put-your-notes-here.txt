Put any .txt files here to include them in the RAG index.
