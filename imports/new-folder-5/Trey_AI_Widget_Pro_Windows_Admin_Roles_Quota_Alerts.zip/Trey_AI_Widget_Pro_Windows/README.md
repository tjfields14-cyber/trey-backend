# Trey AI Widget — PRO (Windows)
## Admin + Per‑Key Analytics + Themes + **Roles** + **Daily Quotas** + **Alerts**

New:
- **Roles:** `viewer` (chat only), `power` (chat + non-admin extras), `admin-proxy` (avoid; near-full).
- **Daily Quotas:** per-key `quota_per_day` with UTC midnight reset. 429 when exceeded.
- **Webhook Alerts:** global webhook URL + threshold % (default 80%). Alerts on threshold-cross and on quota-exhausted.
- **Admin Settings:** `GET/POST /api/settings` to set `webhook_url`, `alert_threshold_percent`.

Run:
```powershell
ollama pull llama3:8b
ollama pull mxbai-embed-large

copy .env.sample .env
# set WIDGET_SECRET
npm install
npm run index
npm run dev
```

Admin dashboard at `/admin.html` lets you: create/revoke keys, see per-key analytics, set alerts, and view remaining quota.
