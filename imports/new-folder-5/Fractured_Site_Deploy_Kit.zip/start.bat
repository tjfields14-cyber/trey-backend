@echo off
cd /d %~dp0site
python -m http.server 8080
echo.
echo Server running at http://localhost:8080/
pause
