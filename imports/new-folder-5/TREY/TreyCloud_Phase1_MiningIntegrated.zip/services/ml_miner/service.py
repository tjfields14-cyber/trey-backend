
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

class MLMiner:
    def cluster_texts(self, texts, k=3):
        vec = TfidfVectorizer(stop_words="english")
        X = vec.fit_transform(texts)
        model = KMeans(n_clusters=k, n_init=10)
        labels = model.fit_predict(X)
        return list(labels)

    def top_terms(self, texts, n=10):
        vec = TfidfVectorizer(stop_words="english")
        X = vec.fit_transform(texts)
        terms = vec.get_feature_names_out()
        sums = X.sum(axis=0)
        data = [(terms[i], sums[0, i]) for i in range(len(terms))]
        data.sort(key=lambda x: x[1], reverse=True)
        return data[:n]
