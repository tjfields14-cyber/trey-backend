@echo off
REM Start the Trey Widget (proxy + web) after ensuring .env exists
IF NOT EXIST .env (
  echo Creating .env from .env.sample
  copy .env.sample .env >NUL
)
echo Installing dependencies...
npm install
echo Starting proxy + dev web server...
npm run dev
