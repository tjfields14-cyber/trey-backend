from fastapi import APIRouter
router = APIRouter(prefix="/characters", tags=["characters"])

@router.get("/")
def list_characters():
    return {"characters": []}

@router.get("/{name}")
def character_detail(name: str):
    return {"name": name, "details": "Character details placeholder"}
