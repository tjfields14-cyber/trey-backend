@echo off
IF "%~1"=="" (
  echo Please pass the full path to nssm.exe, e.g. scripts\unregister-service.bat "C:\nssm\nssm.exe"
  exit /b 1
)
set NSSM=%~1
set SVC=TreyWidget
"%NSSM%" stop %SVC%
"%NSSM%" remove %SVC% confirm
echo Service %SVC% removed.
