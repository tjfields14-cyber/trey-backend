
import weaviate

class WeaviateCloud:
    def __init__(self, url, key):
        self.client = weaviate.Client(url=url, additional_headers={"Authorization": f"Bearer {key}"})

    def add(self, class_name, objects):
        with self.client.batch as batch:
            for obj in objects:
                batch.add_data_object(obj, class_name)

    def query(self, class_name, vector, n=5):
        return (
            self.client.query.get(class_name, ["content","source"])
            .with_near_vector({"vector": vector})
            .with_limit(n)
            .do()
        )
