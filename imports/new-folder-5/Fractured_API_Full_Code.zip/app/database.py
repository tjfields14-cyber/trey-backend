import psycopg2, os
from dotenv import load_dotenv

load_dotenv()

def get_conn():
    return psycopg2.connect(
        dbname="fractured",
        user="fractured_user",
        password=os.getenv("DB_PASSWORD"),
        host="localhost",
        port="5432"
    )
