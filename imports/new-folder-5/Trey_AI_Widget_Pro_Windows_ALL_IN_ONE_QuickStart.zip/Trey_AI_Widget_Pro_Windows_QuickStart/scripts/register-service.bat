@echo off
echo Use the full bundle's scripts for service registration.
