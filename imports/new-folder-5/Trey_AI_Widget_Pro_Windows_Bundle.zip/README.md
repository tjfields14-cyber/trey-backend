# Trey AI Widget Pro (Windows Bundle)

Installer, Uninstaller, Reset scripts included.