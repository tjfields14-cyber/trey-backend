# Trey AI Widget — PRO (Windows) — ALL-IN-ONE 2.0
Includes: multi-user API keys, per-key limits, roles, quotas, alerts (Slack + webhooks), test-alerts, admin dashboard, themes, per-key analytics, CSV/Logs, and a minimal SQLite RAG.
## Quick Start
```powershell
ollama pull llama3:8b
ollama pull mxbai-embed-large

copy .env.sample .env
# set WIDGET_SECRET
npm install
npm run index
npm run dev
```
- User UI: http://localhost:5173
- Admin: http://localhost:5173/admin.html
