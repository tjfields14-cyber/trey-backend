Fractured API Starter Kit

This package contains the project structure.