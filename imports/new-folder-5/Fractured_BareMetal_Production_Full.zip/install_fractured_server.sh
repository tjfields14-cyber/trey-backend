#!/usr/bin/env bash
set -e

SERVICE_USER="fracturedsvc"
PROJECT_ROOT="/home/${SERVICE_USER}/fractured_api"
PYTHON_BIN="python3"

echo "==> Creating service user (${SERVICE_USER}) if not exists..."
if ! id "${SERVICE_USER}" >/dev/null 2>&1; then
  sudo adduser --system --home "/home/${SERVICE_USER}" --shell /bin/bash "${SERVICE_USER}"
  sudo mkdir -p "/home/${SERVICE_USER}"
  sudo chown "${SERVICE_USER}:${SERVICE_USER}" "/home/${SERVICE_USER}"
fi

echo "==> Updating system and installing base packages..."
sudo apt update
sudo apt install -y ${PYTHON_BIN} python3-venv python3-pip postgresql postgresql-contrib cloudflared git curl

echo "==> Creating project directory..."
sudo -u "${SERVICE_USER}" mkdir -p "${PROJECT_ROOT}"
sudo -u "${SERVICE_USER}" mkdir -p "${PROJECT_ROOT}/logs"
cd "${PROJECT_ROOT}"

echo "==> Creating Python virtualenv..."
sudo -u "${SERVICE_USER}" ${PYTHON_BIN} -m venv "${PROJECT_ROOT}/venv"

echo "==> Writing requirements.txt..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/requirements.txt" >/dev/null
fastapi
uvicorn[standard]
psycopg2-binary
python-docx
python-dotenv
EOF

echo "==> Installing Python dependencies..."
sudo -u "${SERVICE_USER}" "${PROJECT_ROOT}/venv/bin/pip" install --upgrade pip
sudo -u "${SERVICE_USER}" "${PROJECT_ROOT}/venv/bin/pip" install -r "${PROJECT_ROOT}/requirements.txt"

echo "==> Setting up PostgreSQL (DB + user + schema)..."
sudo -u postgres psql << 'EOF'
DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_catalog.pg_roles WHERE rolname = 'fractured_user'
   ) THEN
      CREATE ROLE fractured_user LOGIN PASSWORD 'ChangeThisDBPassword!';
   END IF;
END
$$;

DO
$$
BEGIN
   IF NOT EXISTS (
      SELECT FROM pg_database WHERE datname = 'fractured'
   ) THEN
      CREATE DATABASE fractured OWNER fractured_user;
   END IF;
END
$$;
EOF

echo "==> Creating app directory structure..."
sudo -u "${SERVICE_USER}" mkdir -p "${PROJECT_ROOT}/app/routes" "${PROJECT_ROOT}/app/db" "${PROJECT_ROOT}/app/utils" "${PROJECT_ROOT}/scripts"

echo "==> Writing .env..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/.env" >/dev/null
DB_HOST=localhost
DB_PORT=5432
DB_NAME=fractured
DB_USER=fractured_user
DB_PASSWORD=ChangeThisDBPassword!
EOF

echo "==> Writing DB connection module..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/db/connection.py" >/dev/null
import os
from psycopg2 import pool
from dotenv import load_dotenv

load_dotenv()

DB_POOL = pool.SimpleConnectionPool(
    minconn=1,
    maxconn=10,
    user=os.getenv("DB_USER"),
    password=os.getenv("DB_PASSWORD"),
    host=os.getenv("DB_HOST"),
    port=os.getenv("DB_PORT", "5432"),
    database=os.getenv("DB_NAME"),
)

def get_conn():
    return DB_POOL.getconn()

def release_conn(conn):
    DB_POOL.putconn(conn)
EOF

echo "==> Writing core FastAPI app..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/main.py" >/dev/null
from fastapi import FastAPI
from app.routes import manuscript, characters, timeline, sql

app = FastAPI(title="Fractured Universe API", version="1.0")

app.include_router(manuscript.router)
app.include_router(characters.router)
app.include_router(timeline.router)
app.include_router(sql.router)

@app.get("/")
def health():
    return {"status": "ok"}
EOF

echo "==> Writing route modules..."
# manuscript
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/routes/manuscript.py" >/dev/null
from fastapi import APIRouter
from app.db.connection import get_conn, release_conn

router = APIRouter(prefix="/manuscript", tags=["manuscript"])

@router.get("/chapter/{chapter_number}")
def get_chapter(chapter_number: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, title, word_count FROM chapters WHERE chapter_number=%s", (chapter_number,))
    row = cur.fetchone()
    if not row:
        release_conn(conn)
        return {"error": "Chapter not found"}
    chapter_id, title, wc = row

    cur.execute(
        "SELECT paragraph_number, text FROM paragraphs WHERE chapter_id=%s ORDER BY paragraph_number",
        (chapter_id,),
    )
    paragraphs = [{"paragraph_number": r[0], "text": r[1]} for r in cur.fetchall()]
    release_conn(conn)
    return {"chapter_number": chapter_number, "title": title, "word_count": wc, "paragraphs": paragraphs}
EOF

# characters
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/routes/characters.py" >/dev/null
from fastapi import APIRouter
router = APIRouter(prefix="/characters", tags=["characters"])

@router.get("/")
def list_characters():
    return {"characters": []}

@router.get("/{name}")
def get_character(name: str):
    return {"name": name, "details": "Character details placeholder"}
EOF

# timeline
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/routes/timeline.py" >/dev/null
from fastapi import APIRouter
router = APIRouter(prefix="/timeline", tags=["timeline"])

@router.get("/")
def get_timeline():
    return {"events": []}
EOF

# sql (read-only)
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/routes/sql.py" >/dev/null
from fastapi import APIRouter
from app.db.connection import get_conn, release_conn

router = APIRouter(prefix="/sql", tags=["sql"])

FORBIDDEN = ["insert", "update", "delete", "drop", "alter", "truncate"]

@router.post("/query")
def read_only_query(query: str):
    lowered = query.lower()
    if not lowered.strip().startswith("select"):
        return {"error": "Only SELECT queries allowed"}
    if any(bad in lowered for bad in FORBIDDEN):
        return {"error": "Write operations are not allowed."}

    conn = get_conn()
    cur = conn.cursor()
    cur.execute(query)
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description]
    release_conn(conn)

    return {"columns": cols, "rows": rows}
EOF

echo "==> Writing production schema..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/scripts/create_schema.sql" >/dev/null
CREATE TABLE IF NOT EXISTS chapters (
    id SERIAL PRIMARY KEY,
    chapter_number INT NOT NULL UNIQUE,
    title TEXT,
    word_count INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS paragraphs (
    id SERIAL PRIMARY KEY,
    chapter_id INT REFERENCES chapters(id) ON DELETE CASCADE,
    paragraph_number INT,
    text TEXT
);

CREATE TABLE IF NOT EXISTS characters (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE,
    summary TEXT
);

CREATE TABLE IF NOT EXISTS appearances (
    id SERIAL PRIMARY KEY,
    character_id INT REFERENCES characters(id) ON DELETE CASCADE,
    chapter_id INT REFERENCES chapters(id) ON DELETE CASCADE,
    paragraph_id INT REFERENCES paragraphs(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS timeline_events (
    id SERIAL PRIMARY KEY,
    label TEXT,
    description TEXT,
    chapter_number INT,
    position TEXT
);
EOF

echo "==> Applying schema..."
sudo -u "${SERVICE_USER}" bash -c "psql -U fractured_user -d fractured -f '${PROJECT_ROOT}/scripts/create_schema.sql'"

echo "==> Writing manuscript loader..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/scripts/load_manuscript.py" >/dev/null
import sys
from docx import Document
from app.db.connection import get_conn, release_conn

def load_docx(path: str):
    doc = Document(path)
    conn = get_conn()
    cur = conn.cursor()

    chapter_id = None
    paragraph_number = 0

    for p in doc.paragraphs:
        text = p.text.strip()
        if not text:
            continue

        if text.lower().startswith("chapter "):
            parts = text.split()
            try:
                chapter_number = int(parts[1])
            except (IndexError, ValueError):
                continue
            cur.execute(
                "INSERT INTO chapters (chapter_number, title) VALUES (%s, %s) "
                "ON CONFLICT(chapter_number) DO UPDATE SET title=EXCLUDED.title RETURNING id;",
                (chapter_number, text),
            )
            chapter_id = cur.fetchone()[0]
            paragraph_number = 0
        else:
            if chapter_id is None:
                continue
            paragraph_number += 1
            cur.execute(
                "INSERT INTO paragraphs (chapter_id, paragraph_number, text) VALUES (%s, %s, %s);",
                (chapter_id, paragraph_number, text),
            )

    conn.commit()
    release_conn(conn)
    print("Manuscript loaded successfully.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/load_manuscript.py /path/to/file.docx")
        sys.exit(1)
    load_docx(sys.argv[1])
EOF

echo "==> Writing batch loader..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/scripts/batch_load.py" >/dev/null
import sys
from pathlib import Path
from scripts.load_manuscript import load_docx

def batch_load(folder: str):
    root = Path(folder)
    if not root.is_dir():
        print("Not a folder:", folder)
        return
    for docx in root.glob("*.docx"):
        print("Loading:", docx)
        load_docx(str(docx))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scripts/batch_load.py /path/to/folder")
        sys.exit(1)
    batch_load(sys.argv[1])
EOF

echo "==> Writing character extractor stub..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/scripts/character_extractor.py" >/dev/null
import re
from app.db.connection import get_conn, release_conn

CHARACTER_NAMES = ["Valentine", "Johnari", "Kadair"]

def index_character_appearances():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, text, chapter_id FROM paragraphs ORDER BY id;")
    rows = cur.fetchall()

    for paragraph_id, text, chapter_id in rows:
        for name in CHARACTER_NAMES:
            if re.search(rf"\\b{name}\\b", text):
                cur.execute(
                    "INSERT INTO appearances (character_id, chapter_id, paragraph_id) "
                    "SELECT id, %s, %s FROM characters WHERE name=%s "
                    "ON CONFLICT DO NOTHING;",
                    (chapter_id, paragraph_id, name),
                )

    conn.commit()
    release_conn(conn)
    print("Character appearances indexed.")

if __name__ == "__main__":
    index_character_appearances()
EOF

echo "==> Writing timeline builder stub..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/scripts/timeline_builder.py" >/dev/null
from app.db.connection import get_conn, release_conn

def rebuild_timeline_stub():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("TRUNCATE TABLE timeline_events;")
    cur.execute(
        "INSERT INTO timeline_events (label, description, chapter_number, position) "
        "VALUES (%s, %s, %s, %s);",
        ("First Fracture", "Placeholder event in timeline", 1, "start"),
    )
    conn.commit()
    release_conn(conn)
    print("Timeline rebuilt (stub).")

if __name__ == "__main__":
    rebuild_timeline_stub()
EOF

echo "==> Writing semantic search stub..."
cat << 'EOF' | sudo -u "${SERVICE_USER}" tee "${PROJECT_ROOT}/app/utils/semantic_search.py" >/dev/null
def semantic_search_stub(query: str):
    return {
        "query": query,
        "results": [],
        "note": "Semantic search not yet implemented."
    }
EOF

echo "==> Writing systemd service for API..."
cat << EOF | sudo tee /etc/systemd/system/fractured-api.service >/dev/null
[Unit]
Description=Fractured Universe API
After=network.target postgresql.service

[Service]
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${PROJECT_ROOT}
Environment="PYTHONUNBUFFERED=1"
ExecStart=${PROJECT_ROOT}/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
Restart=always
StandardOutput=append:${PROJECT_ROOT}/logs/api.log
StandardError=append:${PROJECT_ROOT}/logs/api_error.log

[Install]
WantedBy=multi-user.target
EOF

echo "==> Reloading systemd and enabling API service..."
sudo systemctl daemon-reload
sudo systemctl enable fractured-api.service
sudo systemctl start fractured-api.service

echo "==> Base installation COMPLETE."
echo "Next steps:"
echo "  - Confirm API: curl http://localhost:8000/"
echo "  - Install and configure Cloudflare Tunnel for external access."
