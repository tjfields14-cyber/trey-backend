
from fastapi import APIRouter
from vector_index.semantic_pipeline import HybridSemanticIndexer

router = APIRouter(prefix="/semantic")

indexer = HybridSemanticIndexer(use_local=True, use_cloud=False)

@router.post("/ingest")
def ingest_text(text: str, source: str):
    return indexer.ingest(text, source)

@router.get("/search")
def search_text(q: str, n: int = 5):
    return indexer.search(q, n)
