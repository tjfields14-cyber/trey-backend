Fractured Bare-Metal Production Bundle
======================================

This bundle contains:

- install_fractured_server.sh  (master installer for Ubuntu + dedicated user 'fracturedsvc')
- configs/cloudflared-fractured.service (systemd unit template for Cloudflare Tunnel)
- configs/fractured-api.yml (Cloudflare Tunnel config)
- fractured_api.openapi.json (for Custom GPT actions)
- scripts and app stubs created by the installer on the server

Usage:

1. Copy this bundle to your Ubuntu machine.
2. Edit passwords / YOUR_MAIN_USER / YOURSUBDOMAIN in config files.
3. Run: chmod +x install_fractured_server.sh
4. Run: ./install_fractured_server.sh
5. Configure Cloudflare Tunnel and enable its systemd service.
6. Upload fractured_api.openapi.json into your Custom GPT actions.
