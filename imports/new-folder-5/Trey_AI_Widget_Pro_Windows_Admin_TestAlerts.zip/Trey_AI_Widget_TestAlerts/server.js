import express from "express";
import fetch from "node-fetch";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { customAlphabet } from "nanoid";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ADMIN_SECRET = process.env.WIDGET_SECRET || "";
const PROXY_PORT = Number(process.env.PROXY_PORT || 3000);

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(morgan("dev"));

const dataDir = path.join(__dirname, "data");
const settingsPath = path.join(dataDir, "settings.json");
const keysPath = path.join(dataDir, "keys.json");
let settings = JSON.parse(fs.readFileSync(settingsPath, "utf-8"));
let keys = JSON.parse(fs.readFileSync(keysPath, "utf-8")).keys;

function saveSettings(){ fs.writeFileSync(settingsPath, JSON.stringify(settings,null,2)); }
function saveKeys(){ fs.writeFileSync(keysPath, JSON.stringify({keys},null,2)); }
function adminOnly(req,res,next){ const tok = req.headers["x-admin-secret"]; if (ADMIN_SECRET && tok === ADMIN_SECRET) return next(); return res.status(401).json({ error:"Admin Unauthorized" }); }

// settings & keys (read-only here)
app.get("/api/settings", adminOnly, (req,res)=> res.json(settings));
app.get("/api/keys", adminOnly, (req,res)=> res.json({keys}));

// --- Alert helpers (generic + Slack), reused by test endpoint
async function sendSlack(url, title, text, color){
  const payload = { attachments: [{ color: color || "#fcd34d", title, text, mrkdwn_in:["text"] }] };
  try{ await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(payload) }); }catch(e){ console.warn("Slack webhook failed:", e.message); }
}
async function sendGeneric(url, obj){
  try{ await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(obj) }); }catch(e){ console.warn("Generic webhook failed:", e.message); }
}

// --- NEW: test alerts endpoint
// POST /api/test-alerts { kind: "threshold"|"exhausted", key: "<optional key id or name>" }
app.post("/api/test-alerts", adminOnly, async (req,res)=>{
  const { kind = "threshold", key: keyQuery = "" } = req.body || {};
  let rec = null;
  if (keyQuery){
    rec = keys.find(k => k.key === keyQuery || (k.name||"").toLowerCase() === String(keyQuery).toLowerCase());
  }
  // fallback: use a fake sample
  if (!rec) rec = { key:"sampleKEY", name:"Sample Key", role:"viewer", quota_per_day:500, used_today: kind==="threshold"? 420 : 500, usage_day: new Date().toISOString().slice(0,10), webhook_url:"", threshold_percent:null };
  const percent = rec.quota_per_day ? Math.round((rec.used_today/rec.quota_per_day)*100) : null;
  const obj = { kind, key: rec.key, name: rec.name, role: rec.role, quota_per_day: rec.quota_per_day, used_today: rec.used_today, usage_day: rec.usage_day, percent, ts: new Date().toISOString(), test:true };

  const title = kind === "threshold" ? "⚠️ (TEST) Quota threshold reached" : "⛔ (TEST) Quota exhausted";
  const lines = [
    `*Key:* ${rec.name || rec.key.slice(0,6)}`,
    `*Role:* ${rec.role}`,
    `*Used Today:* ${rec.used_today}${rec.quota_per_day?` / ${rec.quota_per_day}`:""}`,
    rec.quota_per_day? `*Percent:* ${percent}%` : null,
    `*Date (UTC):* ${rec.usage_day}`
  ].filter(Boolean).join("\n");

  const targets = [];
  if (rec.webhook_url) targets.push({ type:"generic", url: rec.webhook_url });
  if (settings.slack_webhook_url) targets.push({ type:"slack", url: settings.slack_webhook_url });
  if (settings.webhook_url) targets.push({ type:"generic", url: settings.webhook_url });

  let sent = 0;
  for (const t of targets){
    if (t.type === "slack"){ await sendSlack(t.url, title, lines, kind==="threshold"?"#f59e0b":"#ef4444"); sent++; }
    else { await sendGeneric(t.url, obj); sent++; }
  }
  res.json({ ok:true, sent, sample: obj, targets: targets.map(t=>t.type) });
});

// static admin page
app.use(express.static(path.join(__dirname, "public")));

app.listen(PROXY_PORT, ()=> console.log(`TestAlerts server on http://localhost:${PROXY_PORT}`));
