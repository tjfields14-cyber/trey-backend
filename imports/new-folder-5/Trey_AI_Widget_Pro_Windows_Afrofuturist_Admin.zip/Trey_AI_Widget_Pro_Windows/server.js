import express from "express";
import fetch from "node-fetch";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { customAlphabet } from "nanoid";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MODEL = process.env.MODEL || "llama3:8b";
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const PROXY_PORT = Number(process.env.PROXY_PORT || 3000);
const WEB_PORT = Number(process.env.WEB_PORT || 5173);
const ADMIN_SECRET = process.env.WIDGET_SECRET || "";
const RATE_WINDOW_MS = Number(process.env.RATE_WINDOW_MS || 60000);
const RATE_MAX = Number(process.env.RATE_MAX || 60);

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(morgan("dev"));

const limiter = rateLimit({ windowMs: RATE_WINDOW_MS, max: RATE_MAX });
app.use(limiter);

// ---- API keys store (JSON on disk + memory) ----
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const keysPath = path.join(dataDir, "keys.json");
if (!fs.existsSync(keysPath)) fs.writeFileSync(keysPath, JSON.stringify({keys:[]}, null, 2));
let keys = JSON.parse(fs.readFileSync(keysPath, "utf-8")).keys; // [{key,name,note,limit,created_at,active}]
const keyUsage = new Map(); // key -> { windowStart, count }
const makeKey = () => customAlphabet("23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz", 40)();

function saveKeys(){ fs.writeFileSync(keysPath, JSON.stringify({keys}, null, 2)); }
function findKey(k){ return keys.find(x => x.key === k && x.active !== false); }

function adminOnly(req,res,next){
  const tok = req.headers["x-admin-secret"];
  if (ADMIN_SECRET && tok === ADMIN_SECRET) return next();
  return res.status(401).json({ error: "Admin Unauthorized" });
}

app.get("/api/keys", adminOnly, (req,res)=>{
  res.json({ keys: keys.map(({key,name,note,limit,created_at,active})=>({key,name,note,limit,created_at,active})) });
});

app.post("/api/keys", adminOnly, (req,res)=>{
  const { name = "unnamed", note = "", limit = 60 } = req.body || {};
  const key = makeKey();
  const item = { key, name, note, limit: Number(limit)||60, created_at: new Date().toISOString(), active: true };
  keys.push(item); saveKeys();
  res.json(item);
});

app.delete("/api/keys/:key", adminOnly, (req,res)=>{
  const { key } = req.params;
  const idx = keys.findIndex(k => k.key === key);
  if (idx === -1) return res.status(404).json({ error: "not found" });
  keys[idx].active = false; saveKeys();
  res.json({ ok: true });
});

// ---- Auth: prefer x-api-key; fallback x-widget-secret for compatibility ----
function authClient(req){
  const apiKey = req.headers["x-api-key"];
  if (apiKey){
    const rec = findKey(apiKey);
    if (!rec) return { ok:false, status:401, error:"Invalid API key" };
    // per-key rate limiting
    const now = Date.now();
    let u = keyUsage.get(apiKey);
    if (!u || now - u.windowStart >= RATE_WINDOW_MS) {
      u = { windowStart: now, count: 0 };
    }
    if (u.count >= (rec.limit || 60)) {
      keyUsage.set(apiKey, u);
      return { ok:false, status:429, error:"Key rate limit exceeded" };
    }
    u.count += 1; keyUsage.set(apiKey, u);
    return { ok:true, who: { type:"key", key: apiKey, name: rec.name } };
  }
  // fallback: global secret
  const token = req.headers["x-widget-secret"];
  if (!ADMIN_SECRET) return { ok:true, who: { type:"secretless" } };
  if (token === ADMIN_SECRET) return { ok:true, who: { type:"admin-secret" } };
  return { ok:false, status:401, error:"Unauthorized" };
}

// ---- Daily log rotation ----
const logsDir = path.join(__dirname, "logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
const nano8 = customAlphabet("0123456789abcdef", 8);
let currentDay = new Date().toISOString().slice(0,10);
let sessionId = nano8();
let sessionFile = path.join(logsDir, `SESSION-${currentDay}-${sessionId}.log`);

function rotateIfNeeded(){
  const day = new Date().toISOString().slice(0,10);
  if (day !== currentDay) {
    currentDay = day;
    sessionId = nano8();
    sessionFile = path.join(logsDir, `SESSION-${currentDay}-${sessionId}.log`);
  }
}
function writeLog(obj){ rotateIfNeeded(); fs.appendFileSync(sessionFile, JSON.stringify(obj)+"\n"); }

// ---- Metrics (memory) ----
const startedAt = Date.now();
let requestsTotal = 0;
let streamCharsTotal = 0;
let minuteBuckets = []; // { t: epochMinute, count: n }

function bumpMinute(){ const m = Math.floor(Date.now()/60000); const last = minuteBuckets[minuteBuckets.length-1]; if (!last || last.t !== m){ minuteBuckets.push({ t:m, count:1 }); if (minuteBuckets.length > 720) minuteBuckets.shift(); } else last.count += 1; }
function metrics(){ const nowMin = Math.floor(Date.now()/60000); const lastMin = minuteBuckets.find(b=>b.t===nowMin) || { count:0 }; const mins = Math.max(1, Math.floor((Date.now()-startedAt)/60000)); const sum = minuteBuckets.reduce((a,b)=>a+b.count,0); return { uptime_sec: Math.floor((Date.now()-startedAt)/1000), started_at: new Date(startedAt).toISOString(), requests_total: requestsTotal, stream_chars_total: streamCharsTotal, reqs_last_min: lastMin.count, avg_reqs_per_min: Number((sum/mins).toFixed(2)), session_log_file: path.basename(sessionFile), minute_buckets: minuteBuckets }; }

app.get("/api/health", (req,res)=>{ rotateIfNeeded(); res.json({ ok:true, model: MODEL, ollama: OLLAMA_BASE, sessionLog: path.basename(sessionFile) }); });
app.get("/api/metrics", (req,res)=> res.json(metrics()));
app.get("/api/metrics/csv", (req,res)=>{ const m = metrics(); res.setHeader("Content-Type","text/csv"); res.setHeader("Content-Disposition","attachment; filename=metrics.csv"); let csv = "epoch_minute,iso_minute,count\n"; for (const b of m.minute_buckets){ csv += `${b.t},${new Date(b.t*60000).toISOString()},${b.count}\n`; } csv += `\nstarted_at,${m.started_at}\n`; csv += `uptime_sec,${m.uptime_sec}\n`; csv += `requests_total,${m.requests_total}\n`; csv += `stream_chars_total,${m.stream_chars_total}\n`; csv += `avg_reqs_per_min,${m.avg_reqs_per_min}\n`; res.end(csv); });
app.get("/api/logs/current", (req,res)=>{ rotateIfNeeded(); const fname = path.basename(sessionFile); res.setHeader("Content-Type","text/plain; charset=utf-8"); res.setHeader("Content-Disposition", `attachment; filename=${fname}`); fs.createReadStream(sessionFile).pipe(res); });

// --- SQLite RAG ---
const ragDir = path.join(__dirname, "rag");
const dbPath = path.join(ragDir, "vectors.db");
let db = null;
try { db = new Database(dbPath); db.exec(`CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, text TEXT NOT NULL, vec BLOB NOT NULL);`); } catch (e) { console.warn("SQLite warn:", e.message); }

function cosine(q,v){ let dot=0,nq=0,nv=0; const len=Math.min(q.length,v.length); for(let i=0;i<len;i++){ dot+=q[i]*v[i]; nq+=q[i]*q[i]; nv+=v[i]*v[i]; } return dot/(Math.sqrt(nq)*Math.sqrt(nv)+1e-8); }
async function embed(text){ const r = await fetch(`${OLLAMA_BASE}/api/embeddings`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model: "mxbai-embed-large", prompt: text }) }); const j = await r.json(); return Float32Array.from(j.embedding); }
function allChunks(){ if (!db) return []; const rows = db.prepare("SELECT id,text,vec FROM chunks").all(); return rows.map(r=>({ id:r.id, text:r.text, vec:new Float32Array(new Uint8Array(r.vec).buffer) })); }
let memory = allChunks();

// Chat endpoint
app.post("/api/trey", async (req,res)=>{
  const auth = authClient(req);
  if (!auth.ok) return res.status(auth.status).json({ error: auth.error });
  const now = new Date().toISOString();
  const { messages = [], stream = true } = req.body || {};
  bumpMinute(); requestsTotal += 1;

  let system = `You are Trey, the Chapterhouse assistant. Be concise and helpful.`;
  try{
    const lastUser = [...messages].reverse().find(m=>m.role==="user")?.content || "";
    if (memory.length && lastUser){
      const qv = await embed(lastUser);
      const top = memory.map(ch=>({ score: cosine(qv,ch.vec), text: ch.text })).sort((a,b)=>b.score-a.score).slice(0,4);
      const ctx = top.map(s=>s.text).join("\n---\n");
      system += `\nUse ONLY the following context if relevant:\n${ctx}`;
    }
  }catch(e){ console.warn("RAG:", e.message); }

  const payload = { model: MODEL, messages: [{ role:"system", content: system }, ...messages], stream: Boolean(stream) };
  writeLog({ t: now, event:"request", payload, who: auth.who });

  const upstream = await fetch(`${OLLAMA_BASE}/api/chat`, { method:"POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify(payload) });

  res.setHeader("Content-Type","application/json");
  if (!payload.stream){
    const j = await upstream.json();
    writeLog({ t: new Date().toISOString(), event:"response", data: j });
    try{ streamCharsTotal += JSON.stringify(j).length }catch{}
    return res.json(j);
  } else {
    let acc = "";
    for await (const chunk of upstream.body){
      const part = chunk.toString("utf-8");
      acc += part; streamCharsTotal += part.length;
      res.write(part);
    }
    writeLog({ t: new Date().toISOString(), event:"response_stream_raw", data: acc });
    return res.end();
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.listen(PROXY_PORT, ()=>{
  console.log(`API proxy on http://localhost:${PROXY_PORT}`);
  console.log(`UI on http://localhost:${WEB_PORT}`);
});
