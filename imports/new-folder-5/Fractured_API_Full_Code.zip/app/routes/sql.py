from fastapi import APIRouter
router = APIRouter(prefix="/sql", tags=["sql"])

@router.post("/query")
def read_only_query(query: str):
    return {"query": query, "status": "read-only placeholder"}
