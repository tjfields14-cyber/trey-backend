# Trey AI Widget — PRO (Windows)
## Roles + Quotas + Alerts → **Slack Helper** + **Per‑Key Webhooks**

Adds:
- **Slack alerts** via `slack_webhook_url` with nicely formatted messages.
- **Per‑key webhooks** (`webhook_url`) and optional **per‑key thresholds** (`threshold_percent`).
- Global fallback `webhook_url` + `alert_threshold_percent` still supported.

Admin:
- `GET/POST /api/settings` now supports `slack_webhook_url` (optional).
- Keys include `webhook_url` and `threshold_percent` fields (optional).

Use:
```powershell
ollama pull llama3:8b
ollama pull mxbai-embed-large

copy .env.sample .env
npm install
npm run index
npm run dev
```
