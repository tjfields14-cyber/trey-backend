
from rq import Queue
from redis import Redis
from services.web_miner.service import WebMiner
from services.file_miner.service import FileMiner
from services.db_miner.service import DBMiner
from services.social_miner.service import SocialMiner
from services.ml_miner.service import MLMiner

redis = Redis(host='redis', port=6379)
queue = Queue('trey-queue', connection=redis)

def mine_web_job(url):
    return WebMiner().crawl(url)

def mine_file_job(path):
    txt = FileMiner().extract(path)
    return FileMiner().summarize(txt)

def mine_db_job(conn, query):
    db = DBMiner(conn)
    return db.query(query).to_dict(orient="records")

def mine_social_job(url):
    return SocialMiner().extract_posts(url)

def ml_cluster_job(texts):
    return MLMiner().cluster_texts(texts)
