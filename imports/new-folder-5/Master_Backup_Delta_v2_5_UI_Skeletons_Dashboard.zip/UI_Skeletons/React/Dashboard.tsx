import React from "react";
import { motion } from "framer-motion";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  ChevronRight, Bell, Plus, Search, Settings, PlayCircle, BookOpen, Server, Shield, Users
} from "lucide-react";

// Top navigation
function TopNav() {
  return (
    <div className="w-full h-14 border-b bg-white/60 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto h-full px-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-xl bg-black text-white flex items-center justify-center font-bold">CH</div>
          <span className="font-semibold tracking-tight">Chapterhouse</span>
          <Badge variant="secondary" className="ml-2">staging</Badge>
        </div>
        <div className="hidden md:flex items-center gap-2 w-[420px]">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search projects, drafts, tasks…" className="pl-9" />
          </div>
          <Button variant="outline" size="icon"><Bell className="h-4 w-4" /></Button>
          <Button variant="outline" size="icon"><Settings className="h-4 w-4" /></Button>
          <Button size="sm" className="gap-2"><Plus className="h-4 w-4"/> New</Button>
        </div>
      </div>
    </div>
  );
}

// Left sidebar
function SideNav() {
  const items = [
    { label: "Dashboard", icon: PlayCircle, active: true },
    { label: "Projects", icon: BookOpen },
    { label: "Deployments", icon: Server },
    { label: "Trey AI", icon: Shield },
    { label: "Team & Ops", icon: Users },
    { label: "Settings", icon: Settings },
  ];
  return (
    <aside className="hidden lg:block w-64 shrink-0 border-r bg-white/50 backdrop-blur">
      <div className="p-4 space-y-1">
        {items.map(({ label, icon: Icon, active }) => (
          <Button key={label} variant={active ? "secondary" : "ghost"} className="w-full justify-start gap-2">
            <Icon className="h-4 w-4" /> {label}
          </Button>
        ))}
      </div>
    </aside>
  );
}

// Stat card
function StatCard({ title, value, sub, icon: Icon }:{title:string; value:string; sub:string; icon:any}) {
  return (
    <Card className="hover:shadow-md transition-all">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground mt-1">{sub}</p>
      </CardContent>
    </Card>
  );
}

function QuickStats() {
  const stats = [
    { title: "Drafts", value: "12", sub: "3 updated today", icon: BookOpen },
    { title: "Sales (30d)", value: "$2,340", sub: "▲ 18% vs prev.", icon: ChevronRight },
    { title: "Deployments", value: "3 prod / 1 fail", sub: "last: 12:34 • build #123", icon: Server },
    { title: "IP Alerts", value: "2", sub: "Trademark watch active", icon: Shield },
  ];
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {stats.map((s, i) => (
        <motion.div key={s.title} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
          <StatCard {...s} />
        </motion.div>
      ))}
    </div>
  );
}

function RecentProjects() {
  const items = [
    { title: "Aphorisms of Love", tag: ["romance", "noir"], status: "Draft", updated: "Aug 18, 2025" },
    { title: "World Bible – Vol. 1", tag: ["lore", "reference"], status: "In Review", updated: "Aug 16, 2025" },
    { title: "Storefront Assets", tag: ["branding", "images"], status: "Assets", updated: "Aug 15, 2025" },
  ];
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Recent Projects</CardTitle>
        <Button variant="ghost" size="sm" className="gap-1">View all <ChevronRight className="h-4 w-4"/></Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.map((p) => (
          <div key={p.title} className="flex items-center justify-between rounded-xl border p-3 hover:bg-muted/40">
            <div>
              <div className="font-medium">{p.title}</div>
              <div className="text-xs text-muted-foreground flex gap-2 mt-1">
                <span className="inline-flex items-center gap-1"><Badge variant="outline">{p.status}</Badge></span>
                <span>Updated: {p.updated}</span>
                <Separator orientation="vertical" className="h-4" />
                <span className="flex gap-1">{p.tag.map((t) => <Badge key={t} variant="secondary">{t}</Badge>)}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="secondary">Open</Button>
              <Button size="sm" variant="outline">Publish</Button>
              <Button size="sm" variant="ghost">Share</Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function ActivityTasks() {
  const items = [
    { who: "DevOps", msg: "Runner online (E:/) • build #123", when: "2h ago" },
    { who: "Patent Officer", msg: "Trademark watch updated (2 new)", when: "4h ago" },
    { who: "PA", msg: "Business Plan: Financials updated", when: "yesterday" },
  ];
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Activity & Tasks</CardTitle>
        <Tabs defaultValue="activity" className="w-auto">
          <TabsList>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.map((a) => (
          <div key={a.msg} className="flex items-center justify-between border rounded-xl p-3">
            <div>
              <div className="font-medium">{a.who}</div>
              <div className="text-sm text-muted-foreground">{a.msg}</div>
            </div>
            <div className="text-xs text-muted-foreground">{a.when}</div>
          </div>
        ))}
        <div className="flex justify-end">
          <Button size="sm" variant="outline">Open Board</Button>
        </div>
      </CardContent>
    </Card>
  );
}

function RightContext() {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader><CardTitle>Environment</CardTitle></CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-1">
          <div>Stage: <Badge variant="secondary">staging</Badge></div>
          <div>Build: <span className="font-mono">#123</span></div>
          <div>Storage: 62%</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Trey AI Quick Prompt</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <Input placeholder="Ask Trey about runner setup…" />
          <Button className="w-full">Send</Button>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-900">
      <TopNav />
      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-6">
        <SideNav />
        <main className="flex-1 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
              <p className="text-sm text-muted-foreground">Welcome back. Here’s what’s happening today.</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline">Export CSV</Button>
              <Button className="gap-2"><Plus className="h-4 w-4"/> New Project</Button>
            </div>
          </div>

          <QuickStats />

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <div className="xl:col-span-2 space-y-6">
              <RecentProjects />
              <ActivityTasks />
            </div>
            <div className="xl:col-span-1">
              <RightContext />
            </div>
          </div>
        </main>
      </div>
      <footer className="border-t py-3 text-xs text-muted-foreground">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <div>Status: OK • env: staging • build: #123</div>
          <div>© {new Date().getFullYear()} Chapterhouse</div>
        </div>
      </footer>
    </div>
  );
}
