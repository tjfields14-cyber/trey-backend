# Trey AI Widget — PRO (Windows)
## Admin + Per‑Key Analytics + Theme Switcher

New:
- **/api/metrics/keys** → per‑key totals + last‑minute counts
- **Admin dashboard charts** for per‑key traffic
- **Theme switcher**: Afrofuturist (default), Noir, Celestial (persists via localStorage)

Run:
```powershell
ollama pull llama3:8b
ollama pull mxbai-embed-large

copy .env.sample .env
# set WIDGET_SECRET
npm install
npm run index
npm run dev
```
