# Fractured API – Production Version
Full working FastAPI server with PostgreSQL and manuscript ingestion.
