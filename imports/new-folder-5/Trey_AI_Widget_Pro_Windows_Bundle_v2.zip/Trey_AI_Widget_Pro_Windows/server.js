import express from "express";
import fetch from "node-fetch";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { customAlphabet } from "nanoid";
import rateLimit from "express-rate-limit";
import Database from "better-sqlite3";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MODEL = process.env.MODEL || "llama3:8b";
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const PROXY_PORT = Number(process.env.PROXY_PORT || 3000);
const WEB_PORT = Number(process.env.WEB_PORT || 5173);
const SECRET = process.env.WIDGET_SECRET || "";
const RATE_WINDOW_MS = Number(process.env.RATE_WINDOW_MS || 60000);
const RATE_MAX = Number(process.env.RATE_MAX || 60);

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(morgan("dev"));

const limiter = rateLimit({ windowMs: RATE_WINDOW_MS, max: RATE_MAX });
app.use(limiter);

// auth middleware
app.use((req,res,next) => {
  const token = req.headers["x-widget-secret"];
  if (!SECRET) return next(); // dev pass-through
  if (token === SECRET) return next();
  return res.status(401).json({ error: "Unauthorized" });
});

const logsDir = path.join(__dirname, "logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

const makeSessionFile = () => {
  const ts = new Date().toISOString().replace(/[:.]/g,"-");
  const nano = customAlphabet("0123456789abcdef", 8);
  return path.join(logsDir, `SESSION-${ts}-${nano()}.log`);
};
const sessionFile = makeSessionFile();
const writeLog = (obj) => fs.appendFileSync(sessionFile, JSON.stringify(obj)+"\n");

app.get("/api/health", (req,res)=>{
  res.json({ ok:true, model: MODEL, ollama: OLLAMA_BASE, sessionLog: path.basename(sessionFile) });
});

// --- SQLite RAG ---
const ragDir = path.join(__dirname, "rag");
const dbPath = path.join(ragDir, "vectors.db");
let db = null;
try {
  db = new Database(dbPath);
  db.exec(`CREATE TABLE IF NOT EXISTS chunks(
    id INTEGER PRIMARY KEY,
    text TEXT NOT NULL,
    vec BLOB NOT NULL
  );`);
} catch (e) {
  console.warn("SQLite not available:", e.message);
}

function cosine(q, v) {
  const len = Math.min(q.length, v.length);
  let dot=0, nq=0, nv=0;
  for (let i=0;i<len;i++){ dot += q[i]*v[i]; nq+=q[i]*q[i]; nv+=v[i]*v[i]; }
  return dot / (Math.sqrt(nq)*Math.sqrt(nv) + 1e-8);
}

async function embed(text) {
  const r = await fetch(`${OLLAMA_BASE}/api/embeddings`, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify({ model: "mxbai-embed-large", prompt: text })
  });
  const j = await r.json();
  return Float32Array.from(j.embedding);
}

function loadAllChunks() {
  if (!db) return [];
  const rows = db.prepare("SELECT id, text, vec FROM chunks").all();
  return rows.map(r => ({
    id: r.id,
    text: r.text,
    vec: new Float32Array(new Uint8Array(r.vec).buffer)
  }));
}

let memoryChunks = loadAllChunks();

app.post("/api/trey", async (req,res) => {
  const now = new Date().toISOString();
  const { messages = [], stream = true } = req.body || {};

  // Build RAG context
  let systemPreamble = `You are Trey, the Chapterhouse assistant. Be concise and helpful.`;
  try {
    const lastUser = [...messages].reverse().find(m => m.role === "user")?.content || "";
    if (memoryChunks.length && lastUser) {
      const qv = await embed(lastUser);
      const scored = memoryChunks.map(ch => ({
        score: cosine(qv, ch.vec),
        text: ch.text
      })).sort((a,b)=>b.score-a.score).slice(0,4);
      const context = scored.map(s=>s.text).join("\n---\n");
      systemPreamble += `\nUse ONLY the following context if relevant:\n${context}`;
    }
  } catch (e) {
    console.warn("RAG step failed:", e.message);
  }

  const payload = {
    model: MODEL,
    messages: [
      { role:"system", content: systemPreamble },
      ...messages
    ],
    stream: Boolean(stream)
  };

  writeLog({ t: now, event:"request", payload });

  const upstream = await fetch(`${OLLAMA_BASE}/api/chat`, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify(payload)
  });

  res.setHeader("Content-Type", "application/json");
  if (!payload.stream) {
    const j = await upstream.json();
    writeLog({ t: new Date().toISOString(), event:"response", data: j });
    return res.json(j);
  } else {
    let acc = "";
    for await (const chunk of upstream.body) {
      const part = chunk.toString("utf-8");
      acc += part;
      res.write(part);
    }
    writeLog({ t: new Date().toISOString(), event:"response_stream_raw", data: acc });
    return res.end();
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.listen(PROXY_PORT, () => {
  console.log(`API proxy on http://localhost:${PROXY_PORT}`);
  console.log(`UI on http://localhost:${WEB_PORT} (if running Vite)`);
  console.log(`Session log file: ${path.basename(sessionFile)}`);
});
