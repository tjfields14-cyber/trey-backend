-- PRODUCTION SCHEMA

CREATE TABLE IF NOT EXISTS chapters (
    id SERIAL PRIMARY KEY,
    chapter_number INT NOT NULL,
    title TEXT,
    word_count INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS paragraphs (
    id SERIAL PRIMARY KEY,
    chapter_id INT REFERENCES chapters(id),
    paragraph_number INT,
    text TEXT
);

CREATE TABLE IF NOT EXISTS characters (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE,
    summary TEXT
);

CREATE TABLE IF NOT EXISTS appearances (
    id SERIAL PRIMARY KEY,
    character_id INT REFERENCES characters(id),
    chapter_id INT REFERENCES chapters(id),
    paragraph_id INT REFERENCES paragraphs(id)
);

CREATE TABLE IF NOT EXISTS timeline_events (
    id SERIAL PRIMARY KEY,
    label TEXT,
    description TEXT,
    chapter_number INT,
    position TEXT
);
