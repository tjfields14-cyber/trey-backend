
import chromadb

class ChromaLocal:
    def __init__(self, path='storage/chroma_db'):
        self.client = chromadb.PersistentClient(path)
        self.collection = self.client.get_or_create_collection(name="trey_kb")

    def add(self, ids, embeddings, metadatas, documents):
        self.collection.add(ids=ids, embeddings=embeddings, metadatas=metadatas, documents=documents)

    def query(self, embedding, n=5):
        return self.collection.query(query_embeddings=[embedding], n_results=n)
