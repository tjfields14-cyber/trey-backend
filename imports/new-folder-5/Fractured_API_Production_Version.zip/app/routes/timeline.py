from fastapi import APIRouter
router = APIRouter(prefix="/timeline", tags=["timeline"])

@router.get("/")
def get_timeline():
    return {"timeline": "placeholder"}
