
@echo off
set NSSM=%1
%NSSM% install TreyAIWidget "C:\Program Files\nodejs\node.exe" npm run dev
%NSSM% set TreyAIWidget Start SERVICE_AUTO_START
%NSSM% start TreyAIWidget
