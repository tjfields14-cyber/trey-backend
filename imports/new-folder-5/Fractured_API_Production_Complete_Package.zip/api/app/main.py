from fastapi import FastAPI
from app.routes import manuscript, characters, timeline, sql

app = FastAPI(title="Fractured Universe API", version="1.0")

app.include_router(manuscript.router)
app.include_router(characters.router)
app.include_router(timeline.router)
app.include_router(sql.router)
