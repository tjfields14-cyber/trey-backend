# Trey AI Widget — PRO (Windows) — Bundle v2 (with SQLite RAG ready)

This bundle includes a ready-to-run **SQLite RAG indexer** and sample docs.

## Quick Start (DEV)
1) Install **Ollama**, then pull a model:
   ```powershell
   ollama pull llama3:8b
   ollama pull mxbai-embed-large   # for embeddings
   ```
2) Copy `.env.sample` → `.env` and set `WIDGET_SECRET` (any random string).
3) Install deps and start dev:
   ```powershell
   npm install
   npm run index          # builds rag/vectors.db from rag/docs/*.txt
   npm run dev
   ```
4) UI: http://localhost:5173  
   API: http://localhost:3000/api/trey  (send header: `x-widget-secret: <your secret>`)

## Add Your Knowledge
- Drop `.txt` files into `rag/docs/` and run `npm run index` again.

## Service Mode (Windows)
- Install NSSM from https://nssm.cc
- Register service (Admin PowerShell):
  ```powershell
  scripts\register-service.bat C:\nssm\nssm.exe
  ```
- Unregister:
  ```powershell
  scripts\unregister-service.bat C:\nssm\nssm.exe
  ```

## Scripts
- `npm run dev` — run proxy + dev UI
- `npm run proxy` — run proxy only
- `npm run index` — build SQLite RAG DB from ./rag/docs
- `npm start` — serve built UI + proxy (same as proxy)
