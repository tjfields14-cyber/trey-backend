
Trey AI Widget Pro (Windows)
----------------------------
Includes:
- Windows service mode (NSSM scripts)
- SQLite RAG
- Auth + rate limiting
- Session ID logging

Quick Start:
1. Install Ollama and run: ollama pull llama3:8b
2. npm install
3. npm run dev
4. Open http://localhost:5173

Logs are in /logs/SESSION-*.log
RAG docs go in /rag/docs/, then run: npm run index
