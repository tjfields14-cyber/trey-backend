from fastapi import APIRouter
router = APIRouter(prefix="/manuscript", tags=["manuscript"])

@router.get("/chapter/{chapter_number}")
def get_chapter(chapter_number: int):
    return {"chapter_number": chapter_number, "status": "placeholder"}
