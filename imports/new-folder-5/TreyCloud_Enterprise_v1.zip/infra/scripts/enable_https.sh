
#!/usr/bin/env bash
set -e

DOMAIN="treycloud.local"
EMAIL="you@example.com"

echo "This is a template. For a real public domain, install certbot and run something like:"
echo "  sudo certbot certonly --standalone -d $DOMAIN -m $EMAIL --agree-tos"
echo "Then update infra/nginx/treycloud.conf with the certificate paths and reload nginx."
