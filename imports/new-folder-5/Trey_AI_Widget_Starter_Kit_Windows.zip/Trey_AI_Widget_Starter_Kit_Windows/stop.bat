@echo off
echo Use Ctrl+C in the terminal windows to stop the dev servers.
