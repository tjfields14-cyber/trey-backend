# Trey AI Widget — Windows Starter Kit

This kit lets you run an open‑source model locally with **Ollama**, proxy it through a **Node/Express** server,
add **RAG** (Answer from your files), and **log session info to files** automatically.

## Prereqs (Windows 10/11)
1) Install **Ollama**: https://ollama.com
2) Install **Node.js LTS**: https://nodejs.org
3) (Optional) Install **Docker Desktop** if you want to run Ollama in Docker.

## Quick Start (No Docker)
1) Open **Ollama** app (or run `ollama serve`).
2) Pull a model (pick one):
   ```bat
   ollama pull llama3:8b
   REM or: ollama pull mixtral:8x7b
   REM or: ollama pull phi3:mini
   ```
3) In this folder, open **PowerShell** and run:
   ```powershell
   npm install
   npm run dev
   ```
4) Open: http://localhost:5173  (UI)
   API proxy is at: http://localhost:3000/api/trey

## Quick Start (Docker for Ollama)
1) Install Docker Desktop.
2) In PowerShell in this folder:
   ```powershell
   docker compose up -d
   docker exec -it ollama bash -lc "ollama pull llama3:8b"
   ```
3) Keep the Node app running separately with `npm run dev`.

## Logging (Session Info to File)
- Every chat session has a **session ID** and is logged to `./logs/SESSION-<timestamp>-<uuid>.log`.
- Each user message + model response is appended in JSONL format for traceability.
- Server metadata (model, timings, tokens if available) is also appended per turn.

## RAG (Bring Your Own Knowledge)
- Put small text files into `./rag/docs`. Run `npm run index` to build a tiny vector index (JSON).
- At query time, the server finds top chunks and prepends them as **context** to the model via system message.

## Scripts
- `npm run dev` — run proxy + Vite dev server
- `npm run proxy` — run only API proxy
- `npm run index` — build embeddings for files in ./rag/docs
- `npm run build` — build static UI
- `npm start` — serve the built UI + proxy in one process

## Configure
Copy `.env.sample` to `.env` and edit as needed.
