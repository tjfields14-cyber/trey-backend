#!/usr/bin/env bash
# truncated for brevity in demo
