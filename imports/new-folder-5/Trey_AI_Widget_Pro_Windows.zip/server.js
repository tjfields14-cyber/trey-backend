
const express = require('express');
const fs = require('fs');
const path = require('path');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
app.use(express.json());

// Rate limit
const limiter = rateLimit({ windowMs: 60*1000, max: 60 });
app.use(limiter);

// Auth middleware
app.use((req, res, next) => {
  const token = req.headers['x-widget-secret'];
  if (process.env.WIDGET_SECRET && token !== process.env.WIDGET_SECRET) {
    return res.status(403).json({error: 'Forbidden'});
  }
  next();
});

// Session ID
const sessionId = `SESSION-${new Date().toISOString().replace(/[:.]/g,'-')}.log`;
const logFile = path.join(__dirname, 'logs', sessionId);
fs.writeFileSync(logFile, '');

app.get('/health', (req,res)=>{
  res.json({ status: 'ok', session: sessionId });
});

app.post('/chat', (req,res)=>{
  const turn = { ts: new Date().toISOString(), user: req.body.message };
  fs.appendFileSync(logFile, JSON.stringify(turn) + "\n");
  res.json({ reply: `Echo: ${req.body.message}`, session: sessionId });
});

app.listen(process.env.PORT || 5173, ()=>console.log('Trey AI Widget running'));
