# Pydantic schemas placeholder
