
#!/usr/bin/env bash
set -e

echo "=== Trey Cloud Installer ==="

if ! command -v docker >/dev/null 2>&1; then
  echo "Installing Docker..."
  curl -fsSL https://get.docker.com | sh
fi

if ! command -v docker-compose >/dev/null 2>&1 && ! docker compose version >/dev/null 2>&1; then
  echo "NOTE: This template expects either 'docker compose' or 'docker-compose' to be available."
fi

echo "Starting Trey Cloud stack with docker compose..."
if command -v docker-compose >/dev/null 2>&1; then
  docker-compose up -d --build
else
  docker compose up -d --build
fi

echo "Done. Point your browser at: http://treycloud.local/"
