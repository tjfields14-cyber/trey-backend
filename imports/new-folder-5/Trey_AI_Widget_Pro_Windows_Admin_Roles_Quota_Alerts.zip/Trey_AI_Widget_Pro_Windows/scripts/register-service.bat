@echo off
IF "%~1"=="" (
  echo Please pass the full path to nssm.exe, e.g. scripts\register-service.bat "C:\nssm\nssm.exe"
  exit /b 1
)
set NSSM=%~1
set SVC=TreyWidget
pushd %~dp0
cd ..
set APPDIR=%CD%
popd
"%NSSM%" install %SVC% "C:\Program Files\nodejs\node.exe" "%APPDIR%\server.js"
"%NSSM%" set %SVC% AppDirectory "%APPDIR%"
"%NSSM%" set %SVC% Start SERVICE_AUTO_START
"%NSSM%" set %SVC% AppRestartDelay 5000
"%NSSM%" set %SVC% AppStdout "%APPDIR%\logs\service-out.log"
"%NSSM%" set %SVC% AppStderr "%APPDIR%\logs\service-err.log"
"%NSSM%" start %SVC%
echo Service %SVC% registered.
