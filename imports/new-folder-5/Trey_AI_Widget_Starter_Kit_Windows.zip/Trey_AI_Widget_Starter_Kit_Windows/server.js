import express from "express";
import fetch from "node-fetch";
import morgan from "morgan";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { customAlphabet } from "nanoid";

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MODEL = process.env.MODEL || "llama3:8b";
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const PROXY_PORT = Number(process.env.PROXY_PORT || 3000);
const WEB_PORT = Number(process.env.WEB_PORT || 5173);

const app = express();
app.use(express.json({limit:"2mb"}));
app.use(morgan("dev"));

const logsDir = path.join(__dirname, "logs");
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

const makeSessionFile = () => {
  const ts = new Date().toISOString().replace(/[:.]/g,"-");
  const nano = customAlphabet("0123456789abcdef", 8);
  return path.join(logsDir, `SESSION-${ts}-${nano()}.log`);
};

// rotate per process start (simple)
const sessionFile = makeSessionFile();
const writeLog = (obj) => fs.appendFileSync(sessionFile, JSON.stringify(obj)+"\n");

app.get("/api/health", (req,res)=>{
  res.json({ ok:true, model: MODEL, ollama: OLLAMA_BASE, sessionLog: path.basename(sessionFile) });
});

// minimal RAG: load JSON index if present
const ragDir = path.join(__dirname, "rag");
const ragIndexPath = path.join(ragDir, "index.json");

function cosine(a,b){
  const len = Math.min(a.length,b.length);
  let dot=0,na=0,nb=0;
  for (let i=0;i<len;i++){ dot += a[i]*b[i]; na += a[i]*a[i]; nb += b[i]*b[i]; }
  return dot / (Math.sqrt(na)*Math.sqrt(nb) + 1e-8);
}

let ragIndex = { chunks: [] };
try {
  ragIndex = JSON.parse(fs.readFileSync(ragIndexPath,"utf-8"));
  console.log(`RAG index loaded: ${ragIndex.chunks.length} chunks`);
} catch { console.log("No RAG index found (rag/index.json). Run: npm run index"); }

app.post("/api/trey", async (req,res) => {
  const now = new Date().toISOString();
  const { messages = [], stream = true } = req.body || {};

  // Build RAG context if possible
  let systemPreamble = `You are Trey, the Chapterhouse assistant. Be concise and helpful.`;
  try {
    // Embed the user message via Ollama embeddings if model available in index metadata
    const lastUser = [...messages].reverse().find(m => m.role === "user")?.content || "";
    if (ragIndex?.meta?.embedModel && ragIndex?.chunks?.length && lastUser) {
      const er = await fetch(`${OLLAMA_BASE}/api/embeddings`, {
        method: "POST",
        headers: { "Content-Type":"application/json" },
        body: JSON.stringify({ model: ragIndex.meta.embedModel, prompt: lastUser })
      });
      const ej = await er.json();
      const qv = ej.embedding;
      // score
      const scored = ragIndex.chunks.map(ch => ({
        score: cosine(qv, ch.vec),
        text: ch.text
      })).sort((a,b)=>b.score-a.score).slice(0,4);
      const context = scored.map(s=>s.text).join("\n---\n");
      systemPreamble += `\nUse ONLY the following context if relevant:\n${context}`;
    }
  } catch (e) {
    console.warn("RAG step failed:", e.message);
  }

  const payload = {
    model: MODEL,
    messages: [
      { role:"system", content: systemPreamble },
      ...messages
    ],
    stream: Boolean(stream)
  };

  writeLog({ t: now, event:"request", payload });

  const upstream = await fetch(`${OLLAMA_BASE}/api/chat`, {
    method: "POST",
    headers: { "Content-Type":"application/json" },
    body: JSON.stringify(payload)
  });

  // stream back
  res.setHeader("Content-Type", "application/json");
  if (!payload.stream) {
    const j = await upstream.json();
    writeLog({ t: new Date().toISOString(), event:"response", data: j });
    return res.json(j);
  } else {
    // stream line-by-line; also tee the text into log
    let acc = "";
    for await (const chunk of upstream.body) {
      const part = chunk.toString("utf-8");
      acc += part;
      res.write(part);
    }
    writeLog({ t: new Date().toISOString(), event:"response_stream_raw", data: acc });
    return res.end();
  }
});

// Static UI via Vite dev server proxy (during dev) or from /public (after build)
app.use(express.static(path.join(__dirname, "public")));

app.listen(PROXY_PORT, () => {
  console.log(`API proxy on http://localhost:${PROXY_PORT}`);
  console.log(`Session log file: ${path.basename(sessionFile)}`);
});
