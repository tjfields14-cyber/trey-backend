-- Placeholder schema
CREATE TABLE IF NOT EXISTS chapters (
    id SERIAL PRIMARY KEY,
    chapter_number INT,
    title TEXT
);
