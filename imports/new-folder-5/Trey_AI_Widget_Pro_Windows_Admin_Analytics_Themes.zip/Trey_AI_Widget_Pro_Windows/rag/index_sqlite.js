import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import chokidar from "chokidar";
import dotenv from "dotenv";
import Database from "better-sqlite3";

dotenv.config();
const OLLAMA_BASE = process.env.OLLAMA_BASE || "http://localhost:11434";
const ragDir = path.join(process.cwd(), "rag");
const docsDir = path.join(ragDir, "docs");
const dbPath = path.join(ragDir, "vectors.db");

if (!fs.existsSync(docsDir)) fs.mkdirSync(docsDir, { recursive: true });

function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t = setTimeout(()=>fn(...a), ms); }; }

async function embed(text){
  const r = await fetch(`${OLLAMA_BASE}/api/embeddings`, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ model: "mxbai-embed-large", prompt: text }) });
  const j = await r.json(); return Float32Array.from(j.embedding);
}

function toBlob(f32){ return Buffer.from(f32.buffer); }

async function indexAll(){
  const db = new Database(dbPath);
  db.exec(`CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY, text TEXT NOT NULL, vec BLOB NOT NULL);`);
  const del = db.prepare("DELETE FROM chunks"); del.run();
  const ins = db.prepare("INSERT INTO chunks(text, vec) VALUES(?, ?)");

  const files = fs.readdirSync(docsDir).filter(f=>f.endsWith(".txt"));
  let count = 0;
  for (const file of files){
    const full = path.join(docsDir, file);
    const raw = fs.readFileSync(full, "utf-8");
    const parts = raw.split(/\n\s*\n/g).map(s=>s.trim()).filter(Boolean);
    for (const p of parts){ const vec = await embed(p); ins.run(p, toBlob(vec)); count++; }
  }
  console.log(`Indexed ${count} chunks into ${dbPath}`);
  db.close();
}

if (process.argv.includes("--watch")){
  console.log("Watching ./rag/docs for changes...");
  chokidar.watch(docsDir).on("all", debounce(async ()=>{ try { await indexAll(); } catch(e){ console.error(e); } }, 500));
} else {
  indexAll().catch(e=>console.error(e));
}
