
import sqlalchemy as sa
import pandas as pd

class DBMiner:
    def __init__(self, conn_str: str):
        self.engine = sa.create_engine(conn_str)

    def query(self, sql: str) -> pd.DataFrame:
        return pd.read_sql(sql, self.engine)

    def get_schema(self):
        insp = sa.inspect(self.engine)
        return insp.get_table_names()
