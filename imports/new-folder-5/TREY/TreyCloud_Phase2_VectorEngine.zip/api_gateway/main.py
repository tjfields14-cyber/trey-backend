
from fastapi import FastAPI
from routes.mining import router as mining_router

app = FastAPI()

app.include_router(mining_router)

@app.get("/")
def root():
    return {"status":"Trey Cloud Engine Full Release"}

from routes.semantic import router as semantic_router
app.include_router(semantic_router)
