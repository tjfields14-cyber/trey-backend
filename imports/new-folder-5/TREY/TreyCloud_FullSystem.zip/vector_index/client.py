class VectorClient:
    def __init__(self): pass
