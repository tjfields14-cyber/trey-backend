# Trey AI Widget — PRO (Windows) — Afrofuturist UI (Real API)

This package is wired to the **real /api/trey** endpoint (no mocks). The UI includes the Afrofuturist theme.

## Quick Start
1) Install **Ollama** and pull models:
   ```powershell
   ollama pull llama3:8b
   ollama pull mxbai-embed-large
   ```
2) Copy `.env.sample` → `.env` and set `WIDGET_SECRET` (any string).
3) PowerShell:
   ```powershell
   npm install
   npm run index      # builds rag/vectors.db from rag/docs/*.txt
   npm run dev
   ```
4) UI → http://localhost:5173  
   API → http://localhost:3000/api/trey  (send header: x-widget-secret=<your secret>)

## Service Mode (optional)
- Install NSSM (https://nssm.cc), then:
  ```powershell
  scripts\register-service.bat C:\nssm\nssm.exe
  ```

## Notes
- Session logs written to `logs/SESSION-*.log` (JSON Lines).
- RAG: drop `.txt` files in `rag/docs/` and `npm run index` again.
