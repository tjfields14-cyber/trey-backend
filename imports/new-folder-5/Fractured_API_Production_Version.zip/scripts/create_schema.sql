CREATE TABLE IF NOT EXISTS chapters (
    id SERIAL PRIMARY KEY,
    chapter_number INT NOT NULL,
    title TEXT,
    word_count INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS paragraphs (
    id SERIAL PRIMARY KEY,
    chapter_id INT REFERENCES chapters(id),
    paragraph_number INT,
    text TEXT
);
