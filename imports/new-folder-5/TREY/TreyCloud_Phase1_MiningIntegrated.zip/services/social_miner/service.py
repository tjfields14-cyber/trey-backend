
import requests

class SocialMiner:
    def fetch_json(self, url: str) -> dict:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        return r.json()

    def extract_posts(self, url: str) -> list:
        data = self.fetch_json(url)
        if isinstance(data, dict):
            return data.get("posts", [])
        return []
