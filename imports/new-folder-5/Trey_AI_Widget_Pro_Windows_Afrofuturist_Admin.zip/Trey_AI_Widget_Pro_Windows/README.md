# Trey AI Widget — PRO (Windows)
## Afrofuturist + Metrics + Daily Logs + CSV + **Multi‑User API Keys** + **Admin Page**

### New
- **API keys** with per‑key rate limits and metadata (name, note).
- **Admin dashboard** at `/admin.html` to list/create/revoke keys, view metrics.
- Endpoints:
  - `GET /api/keys` (admin)
  - `POST /api/keys` (admin) body: `{ "name": "Alice", "note": "iOS client", "limit": 60 }`
  - `DELETE /api/keys/:key` (admin)
- Clients send `x-api-key: <key>` **instead of** `x-widget-secret`.
- Admin actions require the server `WIDGET_SECRET` in header `x-admin-secret`.

> Existing global secret auth still works for `/api/trey` if no key is provided, but keys are preferred.

### Quick Start
```powershell
ollama pull llama3:8b
ollama pull mxbai-embed-large

copy .env.sample .env
# set WIDGET_SECRET for admin
npm install
npm run index
npm run dev
```
Open UI: http://localhost:5173  |  Admin: http://localhost:5173/admin.html
