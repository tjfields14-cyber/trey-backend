
@echo off
set NSSM=%1
%NSSM% stop TreyAIWidget
%NSSM% remove TreyAIWidget confirm
