
from fastapi import FastAPI
from routes.mining import router as mining_router

app = FastAPI()

app.include_router(mining_router)

@app.get("/")
def root():
    return {"status":"Trey Cloud Engine Full Release"}
