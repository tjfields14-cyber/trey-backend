
from fastapi import APIRouter
from services.web_miner.service import WebMiner
from services.file_miner.service import FileMiner
from services.db_miner.service import DBMiner
from services.social_miner.service import SocialMiner
from services.ml_miner.service import MLMiner

router = APIRouter(prefix="/mine")

@router.get("/web")
def mine_web(url: str):
    return WebMiner().crawl(url)

@router.get("/file")
def mine_file(path: str):
    text = FileMiner().extract(path)
    return {"summary": FileMiner().summarize(text)}

@router.get("/db")
def mine_db(conn: str, q: str):
    db = DBMiner(conn)
    return db.query(q).to_dict(orient="records")

@router.get("/social")
def mine_social(url: str):
    return SocialMiner().extract_posts(url)

@router.post("/ml")
def ml_cluster(texts: list[str]):
    return {"labels": MLMiner().cluster_texts(texts)}
