
import docx2txt
import os

class FileMiner:
    def extract(self, path: str) -> str:
        ext = os.path.splitext(path)[1].lower()
        if ext in [".docx"]:
            return docx2txt.process(path)
        elif ext in [".txt"]:
            return open(path, "r", encoding="utf8").read()
        else:
            raise ValueError("Unsupported format")

    def summarize(self, text: str, limit=200) -> str:
        return text[:limit] + "..."
