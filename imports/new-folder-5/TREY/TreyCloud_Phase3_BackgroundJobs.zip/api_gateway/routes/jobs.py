
from fastapi import APIRouter
from redis import Redis
from rq import Queue
from workers.jobs import (
    mine_web_job, mine_file_job, mine_db_job,
    mine_social_job, ml_cluster_job
)

router = APIRouter(prefix="/jobs")

redis = Redis(host='redis', port=6379)
queue = Queue('trey-queue', connection=redis)

@router.get("/web")
def enqueue_web(url: str):
    job = queue.enqueue(mine_web_job, url)
    return {"job_id": job.get_id()}

@router.get("/file")
def enqueue_file(path: str):
    job = queue.enqueue(mine_file_job, path)
    return {"job_id": job.get_id()}

@router.get("/db")
def enqueue_db(conn: str, query: str):
    job = queue.enqueue(mine_db_job, conn, query)
    return {"job_id": job.get_id()}

@router.get("/social")
def enqueue_social(url: str):
    job = queue.enqueue(mine_social_job, url)
    return {"job_id": job.get_id()}

@router.post("/ml")
def enqueue_ml(texts: list[str]):
    job = queue.enqueue(ml_cluster_job, texts)
    return {"job_id": job.get_id()}

@router.get("/status")
def job_status(job_id: str):
    job = queue.fetch_job(job_id)
    if not job:
        return {"error": "job not found"}
    return {
        "status": job.get_status(),
        "result": job.result
    }
