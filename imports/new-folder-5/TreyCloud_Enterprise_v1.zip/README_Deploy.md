
# Trey Cloud Deployment Stack (Phase 5)

This bundle contains the deployment scaffolding for Trey Cloud:

- Docker Compose stack
- NGINX reverse proxy configs
- Environment templates
- HTTPS helper scripts
- A one-shot installer script

## 1. Copy Project Layout

This stack assumes the following tree on your server:

- api_gateway/        # FastAPI backend (from earlier phases)
- ui/trey_widget/     # React + TS UI (Phase 4)
- workers/            # RQ worker code (Phase 3)
- infra/              # NGINX + scripts (this bundle)
- env/                # Environment files (this bundle)
- docker-compose.yml  # At project root (this bundle)
- install.sh          # At project root (this bundle)

Place this extracted bundle at the root of your Trey project,
merging with the existing api_gateway, workers, and ui folders from earlier phases.

## 2. /etc/hosts Entry (for treycloud.local)

On the machine *you browse from* (can be your laptop), add:

  127.0.0.1   treycloud.local

If your Trey server runs on another machine (e.g., 192.168.1.50),
point treycloud.local to that IP instead.

## 3. Start the Stack

On the Ubuntu server where Trey Cloud should run:

  chmod +x install.sh
  ./install.sh

This will:

- Ensure Docker is installed
- Build the API, UI, worker images
- Start Redis, API, UI, RQ worker, and NGINX

Once it's up, visit:

  http://treycloud.local/

UI is served at root, API is proxied under /api.

## 4. Enabling HTTPS (Optional, Public Domain Only)

For local development on treycloud.local, HTTPS is not needed.

If you later point a *real* public domain at this server:

1. Update infra/nginx/treycloud.conf `server_name` to that domain.
2. Install certbot on the server.
3. Use infra/scripts/enable_https.sh as a template for acquiring certs.
4. Uncomment the HTTPS server block in treycloud.conf.
5. Reload NGINX: `docker restart trey_nginx`.

## 5. Where to Plug In Earlier Phases

- Phase 1–3 code: goes into api_gateway/ and workers/
- Phase 2 vector engine: lives under vector_index/ (referenced by the API)
- Phase 4 UI: goes into ui/trey_widget/

This deployment stack simply wires everything together so it can run as a cloud service.

