import sys
import psycopg2
from docx import Document

from app.db.connection import get_conn, release_conn

def load_docx(path):
    doc = Document(path)
    conn = get_conn()
    cur = conn.cursor()

    chapter_id = None
    paragraph_number = 0

    for p in doc.paragraphs:
        text = p.text.strip()
        if not text:
            continue

        if text.lower().startswith("chapter "):
            chapter_number = int(text.split()[1])
            cur.execute("INSERT INTO chapters (chapter_number, title) VALUES (%s, %s) RETURNING id;",
                        (chapter_number, text))
            chapter_id = cur.fetchone()[0]
            paragraph_number = 0
        else:
            paragraph_number += 1
            cur.execute(
                "INSERT INTO paragraphs (chapter_id, paragraph_number, text) VALUES (%s, %s, %s);",
                (chapter_id, paragraph_number, text)
            )

    conn.commit()
    release_conn(conn)
    print("Manuscript loaded successfully.")

if __name__ == "__main__":
    load_docx(sys.argv[1])
